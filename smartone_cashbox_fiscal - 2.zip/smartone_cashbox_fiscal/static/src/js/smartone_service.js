/** @odoo-module **/
import { registry } from "@web/core/registry";

export const smartoneService = {
    dependencies: ["notification"],
    start(env, { notification }) {
        async function generateSignature(base64Data, merchantId) {
            console.groupCollapsed("%c [SmartOne] Signature Generation ", "color: #3498db;");
            const message = base64Data + merchantId;
            const msgUint8 = new TextEncoder().encode(message);
            const hashBuffer = await crypto.subtle.digest('SHA-1', msgUint8);
            const hashArray = Array.from(new Uint8Array(hashBuffer));
            const sha1Hex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
            const finalSign = btoa(sha1Hex);
            console.log("SHA1 Hex:", sha1Hex);
            console.groupEnd();
            return finalSign;
        }

        function getFullUrl(url, port, endpoint) {
            if (!url) return false;
            let cleanUrl = url.trim();
            if (!cleanUrl.startsWith('http')) cleanUrl = 'http://' + cleanUrl;
            cleanUrl = cleanUrl.replace(/\/$/, "");
            if (port && !cleanUrl.includes(':' + port)) cleanUrl += ":" + port;
            return `${cleanUrl}/${endpoint}`;
        }

        async function sendRequest(url, dataObj, merchantId) {
            console.group(`%c [SmartOne Request] `, "background: #2c3e50; color: #fff;");
            try {
                const jsonData = JSON.stringify(dataObj);
                const base64Data = btoa(unescape(encodeURIComponent(jsonData)));
                const sign = await generateSignature(base64Data, merchantId);
                const params = new URLSearchParams();
                params.append('data', base64Data);
                params.append('sign', sign);

                const response = await fetch(url, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: params.toString()
                });
                const resultText = await response.text();
                let resultJson = JSON.parse(resultText || "{}");
                console.log("Response:", resultJson);
                return resultJson;
            } catch (error) {
                console.error("API Error:", error);
                throw error;
            } finally {
                console.groupEnd();
            }
        }
        return { getFullUrl, sendRequest };
    },
};
registry.category("services").add("smartone_service", smartoneService);