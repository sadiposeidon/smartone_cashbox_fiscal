/** @odoo-module **/

import { patch } from "@web/core/utils/patch";
import { PaymentScreen } from "@point_of_sale/app/screens/payment_screen/payment_screen";
import { PosOrder } from "@point_of_sale/app/models/pos_order";
import { useService } from "@web/core/utils/hooks";

// 1. Sifariş Modelini Patch edirik
patch(PosOrder.prototype, {
    setup(obj) {
        super.setup(...arguments);
        this.smartone_fiscal_id = this.smartone_fiscal_id || false;
        this.smartone_fiscal_num = this.smartone_fiscal_num || false;
        this.smartone_sent = this.smartone_sent || false;
    },
    export_as_JSON() {
        const json = super.export_as_JSON(...arguments);
        json.smartone_fiscal_id = this.smartone_fiscal_id;
        json.smartone_fiscal_num = this.smartone_fiscal_num;
        return json;
    },
    export_for_printing() {
        const result = super.export_for_printing(...arguments);
        result.smartone_fiscal_id = this.smartone_fiscal_id;
        result.smartone_fiscal_num = this.smartone_fiscal_num;
        return result;
    }
});

// 2. Ödəniş Ekranını Patch edirik
patch(PaymentScreen.prototype, {
    setup() {
        super.setup(...arguments);
        this.smartone = useService("smartone_service");
        this.notification = useService("notification");
        this.pos = useService("pos");
        this.orm = useService("orm");
        this._smartoneConfig = null;
        
        console.log("%c🚀 [SMARTONE] Peşəkar Debugger Aktivləşdirildi!", "color: white; background: #673ab7; padding: 4px; border-radius: 4px; font-weight: bold;");
    },

    /**
     * ADVANCED DEBUG LOG SİSTEMİ
     */
    _smartLog(type, action, data, isError = false) {
        const styles = {
            request: "background: #2196F3; color: white; font-weight: bold; padding: 2px 5px; border-left: 8px solid #0d47a1;",
            response: "background: #4CAF50; color: white; font-weight: bold; padding: 2px 5px; border-left: 8px solid #1b5e20;",
            error: "background: #F44336; color: white; font-weight: bold; padding: 2px 5px; border-left: 8px solid #b71c1c;",
            info: "background: #FF9800; color: white; font-weight: bold; padding: 2px 5px; border-left: 8px solid #e65100;"
        };
        const style = isError ? styles.error : styles[type] || styles.info;
        const icon = isError ? "❌" : (type === 'request' ? "📡" : "✅");
        
        console.groupCollapsed(`%c ${icon} SMARTONE | ${action.toUpperCase()} | ${new Date().toLocaleTimeString()} `, style);
        if (data) {
            console.log("Məlumatın Tipi:", typeof data);
            if (typeof data === 'object') {
                console.table(data);
                console.log("Tam Obyekt:", data);
            } else {
                console.log("Mesaj:", data);
            }
        }
        console.groupEnd();
    },

    async validateOrder(isForceValidate) {
        this._smartLog('info', 'Validayasiya Prosesi', "Sifariş təsdiqlənməyə hazırlanır...");
        const order = this.pos.get_order();
        
        if (!order) {
            this._smartLog('error', 'Validayasiya', "Sifariş obyekti tapılmadı!", true);
            return super.validateOrder(...arguments);
        }

        if (order.smartone_sent || order.smartone_fiscal_id) {
            this._smartLog('info', 'Validayasiya', "Sifariş artıq kassaya göndərilib. Keçid edilir.");
            return super.validateOrder(...arguments);
        }

        if (order.get_total_with_tax() <= 0) {
             this._smartLog('info', 'Validayasiya', "Məbləğ 0 və ya mənfidir, kassa sorğusu atılmır.");
             return super.validateOrder(...arguments);
        }

        try {
            const success = await this.sendToSmartOne(order);
            if (success) {
                order.smartone_sent = true;
                this._smartLog('info', 'Validayasiya', "Kassa əməliyyatı bitdi, Odoo daxili yaddaşa yazılır.");
            }
        } catch (e) {
            this._smartLog('error', 'Validate Xətası', e.message || e, true);
        }

        return super.validateOrder(...arguments);
    },

    async sendToSmartOne(order) {
        try {
            if (!this._smartoneConfig) {
                this._smartoneConfig = await this.orm.call("res.config.settings", "get_smartone_config", [[]]);
            }
            const config = this._smartoneConfig;
            
            const items = [];
            for (const line of order.lines) {
                const product = line.product_id;
                if (!product) continue;

                let taxPrc = 1800; 
                if (line.tax_ids.length > 0) {
                    const tax = this.pos.models["account.tax"].get(line.tax_ids[0]);
                    if (tax) taxPrc = tax.amount * 100;
                }

                items.push({
                    "itemId": product.id.toString(),
                    "itemName": product.display_name || product.name,
                    "itemQty": Math.round(line.qty * 1000),
                    "itemAmount": Math.round(line.price_subtotal_incl * 100),
                    "itemTaxes": [{ "taxName": "ƏDV", "taxCode": "4", "taxPrc": taxPrc, "calcType": 1 }]
                });
            }

            let cash = 0, cashless = 0;
            for (const p of order.payment_ids) {
                if (p.payment_method_id.type === 'cash') cash += p.amount;
                else cashless += p.amount;
            }

            const payload = {
                "docNumber": order.name,
                "amount": Math.round(order.get_total_with_tax() * 100),
                "currency": "AZN",
                "employeeName": this.pos.get_cashier().name,
                "items": items,
                "payments": {
                    "cashAmount": Math.round(cash * 100),
                    "cashlessAmount": Math.round(cashless * 100)
                }
            };

            const url = this.smartone.getFullUrl(config.smartone_url, config.smartone_port, "sale");
            this._smartLog('request', 'Satış Sorğusu (SALE)', { url, payload });

            const res = await this.smartone.sendRequest(url, payload, config.smartone_merchant_id);
            this._smartLog('response', 'Satış Cavabı', res);

            const f_id = res?.fiscalID || res?.fiscalId;
            if (f_id) {
                order.smartone_fiscal_id = f_id;
                order.smartone_fiscal_num = res?.documentID || res?.documentId;
                this.notification.add(`Uğurlu! Fiskal ID: ${f_id}`, { type: "success" });
                return true;
            } else {
                this._smartLog('error', 'Kassa Cavabı', "Fiskal ID cavabda gəlmədi!", true);
                return false;
            }
        } catch (error) {
            this._smartLog('error', 'Kritik API Xətası (SALE)', error.message || error, true);
            return false;
        }
    },

    // --- SMARTONE FRONTEND DÜYMƏLƏRİ (FULL LOGS) ---

    async action_smartone_refund() {
        this._smartLog('info', 'Refund', "İstifadəçi refund düyməsini sıxdı.");
        const order = this.pos.get_order();
        
        if (!order || !order.smartone_fiscal_num) {
            this._smartLog('error', 'Refund', "Fiskal Nömrə yoxdur, refund mümkün deyil.", true);
            this.notification.add("Sifarişin Fiskal ID-si tapılmadı!", { type: "danger" });
            return;
        }

        try {
            if (!this._smartoneConfig) this._smartoneConfig = await this.orm.call("res.config.settings", "get_smartone_config", [[]]);
            const config = this._smartoneConfig;

            const payload = {
                "documentID": order.smartone_fiscal_num,
                "employeeName": this.pos.get_cashier().name
            };
            const url = this.smartone.getFullUrl(config.smartone_url, config.smartone_port, "refund");

            this._smartLog('request', 'Refund Sorğusu', { url, payload });
            const res = await this.smartone.sendRequest(url, payload, config.smartone_merchant_id);
            this._smartLog('response', 'Refund Cavabı', res);

            if (res?.status === 'success' || res?.fiscalID) {
                this.notification.add("Refund uğurla icra olundu.", { type: "success" });
            }
        } catch (e) {
            this._smartLog('error', 'Refund Xətası', e.message || e, true);
        }
    },

    async action_smartone_rollback() {
        this._smartLog('info', 'Rollback', "Son əməliyyatın ləğvi başladılır...");
        try {
            if (!this._smartoneConfig) this._smartoneConfig = await this.orm.call("res.config.settings", "get_smartone_config", [[]]);
            const config = this._smartoneConfig;

            const url = this.smartone.getFullUrl(config.smartone_url, config.smartone_port, "rollback");
            this._smartLog('request', 'Rollback Sorğusu', { url });

            const res = await this.smartone.sendRequest(url, {}, config.smartone_merchant_id);
            this._smartLog('response', 'Rollback Cavabı', res);

            if (res?.status === 'success') {
                this.notification.add("Son əməliyyat ləğv edildi.", { type: "warning" });
            }
        } catch (e) {
            this._smartLog('error', 'Rollback Xətası', e.message || e, true);
        }
    },

    async action_smartone_check_copy() {
        this._smartLog('info', 'Check Copy', "Çek nüsxəsi çapı tələb olunur...");
        try {
            if (!this._smartoneConfig) this._smartoneConfig = await this.orm.call("res.config.settings", "get_smartone_config", [[]]);
            const config = this._smartoneConfig;

            const url = this.smartone.getFullUrl(config.smartone_url, config.smartone_port, "copy");
            this._smartLog('request', 'Copy Sorğusu', { url });

            const res = await this.smartone.sendRequest(url, {}, config.smartone_merchant_id);
            this._smartLog('response', 'Copy Cavabı', res);

            if (res?.status === 'success') {
                this.notification.add("Nüsxə çıxarıldı.", { type: "info" });
            }
        } catch (e) {
            this._smartLog('error', 'Copy Xətası', e.message || e, true);
        }
    }
});