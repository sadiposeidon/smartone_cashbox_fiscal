/** @odoo-module **/

import { patch } from "@web/core/utils/patch";
import { PaymentScreen } from "@point_of_sale/app/screens/payment_screen/payment_screen";
import { useService } from "@web/core/utils/hooks";

patch(PaymentScreen.prototype, {
    setup() {
        super.setup(...arguments);
        this.smartone = useService("smartone_service");
        this.notification = useService("notification");
        this.pos = useService("pos");
        this.orm = useService("orm");
        
        console.log("%c🚀 [SMARTONE] Peşəkar Debugger Aktivdir!", "color: white; background: #673ab7; padding: 4px; border-radius: 4px; font-weight: bold;");
    },

    /**
     * MƏRKƏZİ PEŞƏKAR LOG SİSTEMİ
     * Bütün əməliyyatları (Satış, Refund, Rollback, Copy) vizual qruplaşdırır.
     */
    _smartLog(type, action, data, isError = false) {
        const styles = {
            request: "background: #2196F3; color: white; font-weight: bold; padding: 2px 5px; border-left: 5px solid #0d47a1;",
            response: "background: #4CAF50; color: white; font-weight: bold; padding: 2px 5px; border-left: 5px solid #1b5e20;",
            error: "background: #F44336; color: white; font-weight: bold; padding: 2px 5px; border-left: 5px solid #b71c1c;",
            info: "background: #FF9800; color: white; font-weight: bold; padding: 2px 5px; border-left: 5px solid #e65100;"
        };
        const style = isError ? styles.error : styles[type] || styles.info;
        
        console.groupCollapsed(`%c SMARTONE | ${action.toUpperCase()} | ${new Date().toLocaleTimeString()} `, style);
        if (data) {
            if (typeof data === 'object') {
                console.table(data); // Obyektləri cədvəl kimi göstərir
            } else {
                console.log("Mesaj/Detalları:", data);
            }
        }
        console.groupEnd();
    },

    async validateOrder(isForceValidate) {
        this._smartLog('info', 'Odoo 18 Validate', "Proses Başladı...");
        
        const order = this.pos.get_order();
        
        if (!order) {
            this._smartLog('error', 'Validate', "Sifariş obyekti tapılmadı!", true);
            return super.validateOrder(...arguments);
        }

        if (order.smartone_sent) {
            this._smartLog('info', 'Validate', "Sorğu artıq göndərilib, proses davam etdirilir.");
            return super.validateOrder(...arguments);
        }

        try {
            const smartone_success = await this.sendToSmartOne(order);
            
            if (smartone_success) {
                order.smartone_sent = true; 
                this._smartLog('info', 'Validate', "Kassa prosesi uğurla tamamlandı.");
            } else {
                this._smartLog('error', 'Validate', "Kassa prosesi uğursuz oldu!", true);
            }
        } catch (e) {
            this._smartLog('error', 'Kritik Xəta', e, true);
        }

        return super.validateOrder(...arguments);
    },

    async sendToSmartOne(order) {
        let isSuccess = false;
        try {
            const config = await this.orm.call("res.config.settings", "get_smartone_config", [[]]);
            
            if (!config.smartone_url || !config.smartone_merchant_id) {
                this._smartLog('error', 'Konfiqurasiya', "URL və ya Merchant ID tapılmadı!", true);
                this.notification.add("Kassa tənzimləmələri tapılmadı!", { type: "danger" });
                return false;
            }

            const lines = order.lines || []; 
            const items = [];
            
            for (const line of lines) {
                const product = line.product;
                if (!product) continue;

                items.push({
                    "itemId": product.id.toString(),
                    "itemName": product.display_name || product.name || "Məhsul",
                    "itemQty": Math.round((line.qty || 1) * 1000),
                    "itemAmount": Math.round((line.price_subtotal_incl || 0) * 100),
                    "itemTaxes": [{
                        "taxName": "ƏDV",
                        "taxCode": "4",
                        "taxPrc": 1800,
                        "calcType": 1
                    }]
                });
            }

            const paymentLines = order.payment_ids || [];
            let cashAmount = 0;
            let cashlessAmount = 0;

            paymentLines.forEach(pl => {
                const method = pl.payment_method_id;
                const isCash = method && (method.type === 'cash' || method.is_cash_count);
                if (isCash) cashAmount += pl.amount || 0;
                else cashlessAmount += pl.amount || 0;
            });

            const payload = {
                "docNumber": order.pos_reference || order.name,
                "employeeName": this.pos.get_cashier ? this.pos.get_cashier().name : "Administrator",
                "amount": Math.round((order.get_total_with_tax() || 0) * 100),
                "currency": "AZN",
                "items": items,
                "payments": {
                    "cashAmount": Math.round(cashAmount * 100),
                    "cashlessAmount": Math.round(cashlessAmount * 100)
                }
            };

            const url = this.smartone.getFullUrl(config.smartone_url, config.smartone_port, "sale");
            this._smartLog('request', 'SATIŞ SORĞUSU (SALE)', { url, payload });

            const res = await this.smartone.sendRequest(url, payload, config.smartone_merchant_id);
            this._smartLog('response', 'SATIŞ CAVABI', res);

            const fiscalId = res.fiscalID || res.fiscalId;

            if (res.status === "success" || fiscalId) {
                this.notification.add(`Kassa Çeki: ${fiscalId}`, { type: "success" });
                isSuccess = true;
                
                await this.orm.call("pos.order", "update_smartone_data_from_ui", [
                    order.pos_reference || order.name, 
                    {
                        'fiscalID': fiscalId,
                        'fiscalId': fiscalId, 
                        'documentID': res.documentID || res.documentId
                    }
                ]);

                if (config.smartone_check_status_timer > 0) {
                    setTimeout(async () => {
                        const statusUrl = this.smartone.getFullUrl(config.smartone_url, config.smartone_port, "check_status");
                        this._smartLog('request', 'Status Yoxlanışı', { statusUrl });
                        await this.smartone.sendRequest(statusUrl, { "documentID": res.documentID || res.documentId }, config.smartone_merchant_id);
                    }, config.smartone_check_status_timer * 1000);
                }
            } else {
                this._smartLog('error', 'API Xətası', res, true);
                this.notification.add(`Kassa Xətası: ${res.message || 'ID tapılmadı'}`, { type: "warning" });
            }

        } catch (error) {
            this._smartLog('error', 'Odoo 18 Sorğu Xətası', error, true);
            this.notification.add("Kassa inteqrasiya xətası!", { type: "danger" });
        }
        return isSuccess;
    },

    // --- SMARTONE ƏLAVƏ DÜYMƏLƏR ÜÇÜN LOGLAR ---

    async action_smartone_refund() {
        this._smartLog('info', 'REFUND DÜYMƏSİ', "Geri qaytarma başladıldı.");
        const order = this.pos.get_order();
        try {
            const config = await this.orm.call("res.config.settings", "get_smartone_config", [[]]);
            const url = this.smartone.getFullUrl(config.smartone_url, config.smartone_port, "refund");
            
            const payload = {
                "docNumber": order.name,
                "amount": Math.round(order.get_total_with_tax() * 100)
            };

            this._smartLog('request', 'REFUND SORĞUSU', { url, payload });
            const res = await this.smartone.sendRequest(url, payload, config.smartone_merchant_id);
            this._smartLog('response', 'REFUND CAVABI', res);
            
            if(res.status === "success") this.notification.add("Refund Uğurlu", { type: "success" });
        } catch (e) {
            this._smartLog('error', 'REFUND XƏTASI', e, true);
        }
    },

    async action_smartone_rollback() {
        this._smartLog('info', 'ROLLBACK DÜYMƏSİ', "Son əməliyyatın ləğvi...");
        try {
            const config = await this.orm.call("res.config.settings", "get_smartone_config", [[]]);
            const url = this.smartone.getFullUrl(config.smartone_url, config.smartone_port, "rollback");
            
            this._smartLog('request', 'ROLLBACK SORĞUSU', { url });
            const res = await this.smartone.sendRequest(url, {}, config.smartone_merchant_id);
            this._smartLog('response', 'ROLLBACK CAVABI', res);
        } catch (e) {
            this._smartLog('error', 'ROLLBACK XƏTASI', e, true);
        }
    },

    async action_smartone_check_copy() {
        this._smartLog('info', 'COPY DÜYMƏSİ', "Çek surəti tələbi...");
        try {
            const config = await this.orm.call("res.config.settings", "get_smartone_config", [[]]);
            const url = this.smartone.getFullUrl(config.smartone_url, config.smartone_port, "copy");
            
            this._smartLog('request', 'COPY SORĞUSU', { url });
            const res = await this.smartone.sendRequest(url, {}, config.smartone_merchant_id);
            this._smartLog('response', 'COPY CAVABI', res);
        } catch (e) {
            this._smartLog('error', 'COPY XƏTASI', e, true);
        }
    }
});