# -*- coding: utf-8 -*-
from odoo import models, fields, api
import logging
import requests

_logger = logging.getLogger(__name__)

class PosOrder(models.Model):
    _inherit = 'pos.order'

    smartone_fiscal_id = fields.Char(string="Fiskal ID", readonly=True, copy=False)
    smartone_fiscal_num = fields.Char(string="Fiskal Nömrə", readonly=True, copy=False)
    smartone_qr_url = fields.Char(string="QR Link", compute="_compute_smartone_qr_url", store=True)

    @api.depends('smartone_fiscal_num')
    def _compute_smartone_qr_url(self):
        for order in self:
            if order.smartone_fiscal_num:
                order.smartone_qr_url = f"https://monitoring.e-kassa.az/#/index?doc={order.smartone_fiscal_num}"
            else:
                order.smartone_qr_url = False

    @api.model
    def _order_fields(self, ui_order):
        """ JS-dən gələn datanı (export_as_JSON-dan gəlir) bazaya yazır """
        res = super(PosOrder, self)._order_fields(ui_order)
        res['smartone_fiscal_id'] = ui_order.get('smartone_fiscal_id')
        res['smartone_fiscal_num'] = ui_order.get('smartone_fiscal_num')
        return res

    def _get_smartone_client(self):
        config = self.env['res.config.settings'].sudo().get_smartone_config()
        url = f"http://{config['smartone_url']}:{config['smartone_port']}"
        return url, config['smartone_merchant_id']

    # --- Düymə Əməliyyatları ---
    def action_smartone_refund(self):
        url, m_id = self._get_smartone_client()
        for order in self:
            if order.smartone_fiscal_num:
                _logger.info(f"🔄 [SmartOne] Refund göndərilir: {order.smartone_fiscal_num}")
                try:
                    res = requests.post(f"{url}/refund", json={"documentID": order.smartone_fiscal_num}, timeout=10)
                    return {
                        'type': 'ir.actions.client',
                        'tag': 'display_notification',
                        'params': {
                            'title': 'Qaytarma Sorğusu',
                            'message': f'Kassaya qaytarma sorğusu göndərildi: {res.status_code}',
                            'type': 'warning',
                            'sticky': False,
                        }
                    }
                except Exception as e:
                    _logger.error(f"Refund Xətası: {e}")

    def action_smartone_rollback(self):
        url, m_id = self._get_smartone_client()
        for order in self:
            if order.smartone_fiscal_num:
                _logger.info(f"🚫 [SmartOne] Rollback göndərilir: {order.smartone_fiscal_num}")
                requests.post(f"{url}/rollback", json={"documentID": order.smartone_fiscal_num}, timeout=10)
                return {
                    'type': 'ir.actions.client',
                    'tag': 'display_notification',
                    'params': {
                        'title': 'Ləğv Etmə',
                        'message': 'Ləğv sorğusu (Rollback) göndərildi.',
                        'type': 'danger',
                        'sticky': False,
                    }
                }

    def action_smartone_check_copy(self):
        url, m_id = self._get_smartone_client()
        for order in self:
            if order.smartone_fiscal_num:
                _logger.info(f"📄 [SmartOne] Çek nüsxəsi göndərilir: {order.smartone_fiscal_num}")
                requests.post(f"{url}/check_copy", json={"documentID": order.smartone_fiscal_num}, timeout=10)
                return {
                    'type': 'ir.actions.client',
                    'tag': 'display_notification',
                    'params': {
                        'title': 'Çek Çapı',
                        'message': 'Nüsxə çapı üçün komanda göndərildi.',
                        'type': 'info',
                        'sticky': False,
                    }
                }