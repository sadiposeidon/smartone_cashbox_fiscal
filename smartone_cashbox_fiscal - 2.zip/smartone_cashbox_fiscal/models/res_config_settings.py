# -*- coding: utf-8 -*-
import logging
from odoo import models, fields, api

_logger = logging.getLogger(__name__)

class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'
    
    # Qeyd: config_parameter adlarını metod daxilindəkilərlə eyniləşdirdim
    smartone_url = fields.Char(
        string="URL / IP", 
        config_parameter='smartone_cashbox_fiscal.smartone_url'
    )
    smartone_port = fields.Char(
        string="PORT", 
        config_parameter='smartone_cashbox_fiscal.smartone_port'
    )
    smartone_merchant_id = fields.Char(
        string="MERCHANT ID", 
        config_parameter='smartone_cashbox_fiscal.smartone_merchant_id'
    )
    smartone_document_ext_id = fields.Char(
        string="Document External ID", 
        config_parameter='smartone_cashbox_fiscal.smartone_document_ext_id'
    )
    smartone_check_status_timer = fields.Integer(
        string="CHECK STATUS TIMER", 
        config_parameter='smartone_cashbox_fiscal.smartone_check_status_timer',
        default=3
    )

    @api.model
    def log_smartone_debug(self, data):
        """JS-dən gələn cavabları server terminalında çap edir"""
        _logger.info("=== SMARTONE API RESPONSE START ===")
        _logger.info(data)
        _logger.info("=== SMARTONE API RESPONSE END ===")
        return True

    @api.model
    def get_smartone_config(self, args=None):
        """ JS tərəfindən birbaşa çağırıla bilən tənzimləmə oxuyucu """
        params = self.env['ir.config_parameter'].sudo()
        config_data = {
            'smartone_url': params.get_param('smartone_cashbox_fiscal.smartone_url', ''),
            'smartone_port': params.get_param('smartone_cashbox_fiscal.smartone_port', '8008'),
            'smartone_merchant_id': params.get_param('smartone_cashbox_fiscal.smartone_merchant_id', ''),
            'smartone_check_status_timer': int(params.get_param('smartone_cashbox_fiscal.smartone_check_status_timer', 3)),
        }
        _logger.info("=== GET SMARTONE CONFIG CALLED: %s ===", config_data)
        return config_data

class PosConfig(models.Model):
    _inherit = 'pos.config'

    # Odoo 18 üçün ən stabil metod: Parametrləri POS sessiyasına yükləyir
    def _get_pos_ui_res_config_settings(self, params):
        config = self.env['ir.config_parameter'].sudo()
        res = {
            'smartone_url': config.get_param('smartone_cashbox_fiscal.smartone_url'),
            'smartone_port': config.get_param('smartone_cashbox_fiscal.smartone_port'),
            'smartone_merchant_id': config.get_param('smartone_cashbox_fiscal.smartone_merchant_id'),
            'smartone_check_status_timer': int(config.get_param('smartone_cashbox_fiscal.smartone_check_status_timer', 3)),
        }
        _logger.info("=== POS UI CONFIG LOADED: %s ===", res)
        return res

    # Odoo 18 Loader metodu - Datatın mütləq POS-a yüklənməsini təmin edir
    @api.model
    def _load_pos_data_domain(self, data):
        res = super()._load_pos_data_domain(data)
        return res