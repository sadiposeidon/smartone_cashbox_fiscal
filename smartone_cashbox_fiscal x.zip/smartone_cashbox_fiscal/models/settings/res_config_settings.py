# -*- coding: utf-8 -*-
import logging
import time
import json
import base64
import hashlib
import requests
from datetime import datetime
from odoo import models, fields, api, _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)

class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    # --- Sahə Tərifləri (Odoo 18 Config Parameters) ---
    smartone_ip = fields.Char(string="Kassa IP / URL", config_parameter='smartone.ip')
    smartone_port = fields.Char(string="Port", config_parameter='smartone.port', default="8008")
    smartone_merchant_id = fields.Char(string="Merchant ID", config_parameter='smartone.merchant_id')
    smartone_document_ext_id = fields.Char(string="Sənəd Ext ID", config_parameter='smartone.document_ext_id', default="1")
    smartone_timer_active = fields.Boolean(string="Taymer aktiv edilsin?", config_parameter='smartone.timer_active', default=True)
    smartone_timer = fields.Integer(string="Taymer (san)", config_parameter='smartone.timer', default=3)
    check_copy_button_active = fields.Boolean(string="Təkrar çap", config_parameter='smartone.check_copy_button_active', default=False)

    _last_log_cache = {}

    def _smartone_log_console(self, action_name, message, success=True, data=None):
        """ Professional Terminal Debugging (Console Log) """
        current_time = time.time()
        log_key = f"{action_name}_{message}"
        if log_key in self._last_log_cache and current_time - self._last_log_cache[log_key] < 0.3:
            return
        self._last_log_cache[log_key] = current_time

        marker = "✅ SUCCESS" if success else "❌ FAILURE"
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        border = "═" * 100
        
        log_content = [
            f"\n╔{border}╗",
            f"║ {marker.center(98)} ║",
            f"║ ACTION: {action_name.center(90)} ║",
            f"║ TIMESTAMP: {timestamp.center(87)} ║",
            f"╠{'═' * 100}╣",
            f"║ DETAIL: {str(message)[:90].ljust(90)} ║"
        ]
        
        if data:
            try:
                data_str = json.dumps(data, indent=4, ensure_ascii=False)
                log_content.append(f"╠{' DEBUG INFO '.center(100, '-')}╣")
                for line in data_str.split('\n'):
                    # Uzun sətirləri kəsirik ki, çərçivə pozulmasın
                    while line:
                        log_content.append(f"║ {line[:96].ljust(98)} ║")
                        line = line[96:]
            except:
                log_content.append(f"║ DATA: {str(data)[:90].ljust(90)} ║")
            
        log_content.append(f"╚{border}╝\n")
        
        final_log = "\n".join(log_content)
        if success:
            _logger.info(final_log)
        else:
            _logger.error(final_log)

    def _prepare_smartone_payload(self, data_dict):
        """ 
        SmartOne API v3.9 üçün data və sign hazırlayır.
        İmza üçün JSON-un boşluqsuz olması şərtdir.
        """
        try:
            merchant_id = self.smartone_merchant_id or ""
            # Merchant ID mütləq həm data daxilində, həm də imza zəncirində olmalıdır
            data_dict["merchant_id"] = merchant_id
            
            # 1. Kompakt JSON (boşluqsuz)
            json_data = json.dumps(data_dict, separators=(',', ':'), ensure_ascii=False)
            
            # 2. Base64 Encode
            data_b64 = base64.b64encode(json_data.encode('utf-8')).decode('utf-8')
            
            # 3. SHA1 Hash (base64_data + merchantID)
            raw_string = data_b64 + merchant_id
            sha1_hash = hashlib.sha1(raw_string.encode('utf-8')).hexdigest().lower()
            
            # 4. Sign Base64 Encode
            sign_b64 = base64.b64encode(sha1_hash.encode('utf-8')).decode('utf-8')
            
            return {'data': data_b64, 'sign': sign_b64}
        except Exception as e:
            self._smartone_log_console("PAYLOAD_PREP", f"Kritik Xəta: {str(e)}", success=False)
            return None

    def action_smartone_test_connection(self):
        """ /get_info endpointinə (PING) sorğu göndərir """
        self._smartone_log_console("TEST_CONNECTION_START", "Bağlantı testi başladılır...")
        
        if not self.smartone_ip or not self.smartone_merchant_id:
            raise UserError(_("Xahiş olunur IP və Merchant ID sahələrini doldurun!"))

        url = f"http://{self.smartone_ip}:{self.smartone_port}/get_info"
        payload = self._prepare_smartone_payload({
            "ping": True,
            "timestamp": datetime.now().isoformat()
        })

        try:
            # API v3.9 bəzən parametrləri həm URL-də, həm Body-də gözləyir (Double-payload)
            response = requests.post(url, params=payload, data=payload, timeout=10)
            
            if response.status_code == 200:
                res_data = response.json()
                if res_data.get('status') == 'success':
                    self._smartone_log_console("PING_SUCCESS", "Kassa aktivdir.", success=True, data=res_data)
                    return {
                        'type': 'ir.actions.client',
                        'tag': 'display_notification',
                        'params': {
                            'title': _('Uğurlu'),
                            'message': _('Kassa ilə əlaqə quruldu: %s') % res_data.get('company_name', 'OK'),
                            'type': 'success',
                        }
                    }
                else:
                    self._smartone_log_console("PING_ERROR_RESPONSE", res_data.get('message'), success=False, data=res_data)
                    raise UserError(_("Kassa Xətası: %s") % res_data.get('message'))
            else:
                self._smartone_log_console("HTTP_ERROR", f"Status: {response.status_code}", success=False)
                raise UserError(_("Server cavab vermir: %s") % response.status_code)

        except Exception as e:
            self._smartone_log_console("TEST_EXCEPTION", str(e), success=False)
            raise UserError(_("Əlaqə xətası: %s") % str(e))

    def action_smartone_check_status(self):
        """ /check_status endpointinə sorğu göndərir """
        # Settings-də yazdığınız 'Sənəd Ext ID' burada istifadə olunur
        ext_id = str(self.smartone_document_ext_id or "1")
        self._smartone_log_console("CHECK_STATUS_START", f"ID {ext_id} üçün status sorğulanır...")
        
        url = f"http://{self.smartone_ip}:{self.smartone_port}/check_status"
        payload = self._prepare_smartone_payload({
            "documentExtID": ext_id
        })

        try:
            # Headerləri dəqiqləşdiririk
            headers = {'Content-Type': 'application/x-www-form-urlencoded'}
            
            # Double sending (həm params həm data) 'Header fields empty' xətasını aradan qaldırır
            response = requests.post(url, params=payload, data=payload, headers=headers, timeout=10)
            
            if response.status_code == 200:
                res_data = response.json()
                if res_data.get('status') == 'success':
                    self._smartone_log_console("STATUS_SUCCESS", "Məlumat alındı.", success=True, data=res_data)
                    return {
                        'type': 'ir.actions.client',
                        'tag': 'display_notification',
                        'params': {
                            'title': _('Kassa Statusu'),
                            'message': _('Sənəd vəziyyəti: %s') % res_data.get('state', 'Hazırdır'),
                            'type': 'info',
                        }
                    }
                else:
                    self._smartone_log_console("STATUS_FAIL", res_data.get('message'), success=False, data=res_data)
                    raise UserError(_("Kassa xətası: %s") % res_data.get('message'))
            else:
                raise UserError(_("HTTP Xətası: %s") % response.status_code)
                
        except Exception as e:
            self._smartone_log_console("STATUS_EXCEPTION", str(e), success=False)
            raise UserError(_("Statusu yoxlamaq mümkün olmadı: %s") % str(e))

    def execute(self):
        """ Parametrlər yadda saxlanılan zaman """
        res = super(ResConfigSettings, self).execute()
        self._smartone_log_console("CONFIG_SAVE", "Yeni tənzimləmələr yadda saxlanıldı.", success=True)
        return res