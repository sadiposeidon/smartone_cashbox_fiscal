# -*- coding: utf-8 -*-
import logging
import json
import base64
import hashlib
import requests
import traceback
from datetime import datetime
from odoo import models, fields, api, _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)

class SaleOrder(models.Model):
    _inherit = 'sale.order'

    # --- Sahə Tərifləri ---
    fiscal_document_id = fields.Char(string="Fiskal ID", copy=False)
    fiscal_internal_id = fields.Integer(string="Kassa Daxili ID", copy=False) # documentID (integer olan)
    fiscal_status = fields.Selection([
        ('draft', 'Göndərilməyib'),
        ('sent', 'Fiskallaşdırıldı'),
        ('refunded', 'Geri Qaytarıldı'),
        ('cancelled', 'Ləğv Edildi (Kassa)'),
        ('error', 'Xəta')], default='draft', string="Fiskal Status", copy=False)
    
    fiscal_qr_link = fields.Char(string="QR Link", compute="_compute_fiscal_qr_link", store=False)

    @api.depends('fiscal_document_id')
    def _compute_fiscal_qr_link(self):
        """ Fiskal ID-yə əsasən e-kassa monitoring linkini yaradır """
        for order in self:
            if order.fiscal_document_id:
                order.fiscal_qr_link = f"https://monitoring.e-kassa.gov.az/#/index?doc={order.fiscal_document_id}"
            else:
                order.fiscal_qr_link = False

    def _smartone_log_console(self, action_name, message, success=True, data=None, error_trace=None):
        """ 
        Professional Terminal Debugging 
        Odoo 18 konsolunda bütün prosesi vizual və detallı əks etdirir.
        """
        marker = "🟢 [SUCCESS]" if success else "🔴 [FAILURE]"
        border = "═" * 100
        log_content = [
            f"\n╔{border}╗",
            f"║ {marker.ljust(20)} | ACTION: {action_name.ljust(75)} ║",
            f"╠{'═' * 100}╣",
            f"║ ZAMAN: {datetime.now().strftime('%Y-%m-%d %H:%M:%S').ljust(91)} ║",
            f"║ MESAJ: {str(message).ljust(92)} ║"
        ]
        
        if data:
            data_str = json.dumps(data, indent=4, ensure_ascii=False)
            log_content.append(f"╠{'─' * 100}╣")
            log_content.append("║ MƏLUMAT (JSON PAYLOAD / RESPONSE):".ljust(101) + "║")
            for line in data_str.split('\n'):
                log_content.append(f"║ {line.ljust(98)} ║")
        
        if error_trace:
            log_content.append(f"╠{'─' * 100}╣")
            log_content.append("║ XƏTA DETALLARI (PYTHON STACK TRACE):".ljust(101) + "║")
            for line in error_trace.split('\n')[-10:]:
                log_content.append(f"║ {line.ljust(98)} ║")

        log_content.append(f"╚{border}╝\n")
        
        final_log = "\n".join(log_content)
        if success:
            _logger.info(final_log)
        else:
            _logger.error(final_log)

    def _get_fiscal_tax_mapping(self, tax_amount):
        """ Odoo vergisini kassa API formatına uyğunlaşdırır """
        amount = round(tax_amount)
        if amount == 18:
            return {"taxName": "ƏDV", "taxPrc": 1800, "taxCode": "4", "calcType": 1}
        elif amount == 0:
            return {"taxName": "ƏDV-dən Azad", "taxPrc": 0, "taxCode": "6", "calcType": 1}
        elif amount == 2:
            return {"taxName": "Sadələşdirilmiş Vergi", "taxPrc": 200, "taxCode": "1", "calcType": 3}
        elif amount == 8:
            return {"taxName": "Sadələşdirilmiş Vergi", "taxPrc": 800, "taxCode": "3", "calcType": 3}
        else:
            return {"taxName": "ƏDV", "taxPrc": int(amount * 100), "taxCode": "4", "calcType": 1}

    def _prepare_smartone_payload(self, data_dict):
        """ Məlumatı imzalayıb Base64 formatına salır """
        try:
            merchant_id = self.env['ir.config_parameter'].sudo().get_param('smartone.merchant_id') or ""
            json_data = json.dumps(data_dict, ensure_ascii=False, separators=(',', ':'))
            data_b64 = base64.b64encode(json_data.encode('utf-8')).decode('utf-8')
            
            raw_string = (data_b64 + merchant_id).encode('utf-8')
            sha1_hash = hashlib.sha1(raw_string).hexdigest().lower()
            sign_b64 = base64.b64encode(sha1_hash.encode('utf-8')).decode('utf-8')
            
            return {'data': data_b64, 'sign': sign_b64}
        except Exception:
            self._smartone_log_console("PAYLOAD_PREP", "İmzalama zamanı xəta!", success=False, error_trace=traceback.format_exc())
            raise

    def action_smartone_fiscal_sale(self):
        """ /sale endpointi - Fiskal Çek Çapı """
        self.ensure_one()
        get_param = self.env['ir.config_parameter'].sudo().get_param
        ip = get_param('smartone.ip')
        port = get_param('smartone.port')
        
        if not ip or not port:
            self._smartone_log_console("CONFIG_ERR", "Kassa IP və ya Port ayarlanmayıb!", success=False)
            raise UserError(_("Sistem ayarlarında kassa IP və Portunu daxil edin!"))

        url = f"http://{ip}:{port}/sale"

        items = []
        for line in self.order_line.filtered(lambda l: not l.display_type):
            item_taxes = [self._get_fiscal_tax_mapping(t.amount) for t in line.tax_id] or [self._get_fiscal_tax_mapping(0)]
            items.append({
                "itemId": str(line.product_id.id),
                "itemName": str(line.product_id.name[:50]),
                "itemQty": int(round(line.product_uom_qty * 1000)),
                "itemAmount": int(round(line.price_total * 100)),
                "discount": int(round((line.price_unit * line.product_uom_qty - line.price_subtotal) * 100)),
                "itemTaxes": item_taxes
            })

        sale_data = {
            "docNumber": str(self.name),
            "employeeName": str((self.user_id.name or self.env.user.name)[:30]),
            "amount": int(round(self.amount_total * 100)),
            "currency": "AZN",
            "items": items,
            "payments": {
                "cashAmount": int(round(self.amount_total * 100)),
                "cashlessAmount": 0,
                "otherAmount": 0
            }
        }

        self._smartone_log_console("SALE_SEND", "Satış sorğusu göndərilir.", data=sale_data)
        try:
            response = requests.post(url, data=self._prepare_smartone_payload(sale_data), timeout=15)
            res = response.json()
            if res.get('status') == 'success':
                self.write({
                    'fiscal_document_id': res.get('fiscalID'),
                    'fiscal_internal_id': res.get('documentID'),
                    'fiscal_status': 'sent'
                })
                self._smartone_log_console("SALE_SUCCESS", "Çek uğurla çap olundu.", data=res)
            else:
                self.fiscal_status = 'error'
                self._smartone_log_console("KASSA_REJECT", "Kassa satışı rədd etdi.", success=False, data=res)
        except Exception as e:
            self.fiscal_status = 'error'
            self._smartone_log_console("SALE_CRITICAL_ERR", str(e), success=False, error_trace=traceback.format_exc())

    def action_smartone_fiscal_rollback(self):
        """ /rollback endpointi - Çekin ləğvi (API v3.9 uyğun) """
        self.ensure_one()
        get_param = self.env['ir.config_parameter'].sudo().get_param
        ip = get_param('smartone.ip')
        port = get_param('smartone.port')
        
        if not ip or not port or not self.fiscal_document_id:
            self._smartone_log_console("ROLLBACK_SKIP", "Ləğv üçün çatışmayan məlumat (IP və ya Fiskal ID).", success=False)
            return

        url = f"http://{ip}:{port}/rollback"

        # Sənədə əsasən: Rollback zamanı items, payments və amount məcburidir.
        items = []
        for line in self.order_line.filtered(lambda l: not l.display_type):
            item_taxes = [self._get_fiscal_tax_mapping(t.amount) for t in line.tax_id] or [self._get_fiscal_tax_mapping(0)]
            items.append({
                "itemId": str(line.product_id.id),
                "itemName": str(line.product_id.name[:50]),
                "itemQty": int(round(line.product_uom_qty * 1000)),
                "itemAmount": int(round(line.price_total * 100)),
                "discount": int(round((line.price_unit * line.product_uom_qty - line.price_subtotal) * 100)),
                "itemTaxes": item_taxes
            })

        # DİQQƏT: API sənədinin xüsusi tələbi - documentID olaraq fiscalID göndərilməlidir
        rollback_data = {
            "documentID": str(self.fiscal_document_id), 
            "employeeName": str((self.user_id.name or self.env.user.name)[:30]),
            "docNumber": str(self.name),
            "amount": int(round(self.amount_total * 100)),
            "currency": "AZN",
            "reason": "Odoo tərəfindən ləğv edildi",
            "items": items,
            "payments": {
                "cashAmount": int(round(self.amount_total * 100)),
                "cashlessAmount": 0,
                "otherAmount": 0
            }
        }
        
        self._smartone_log_console("ROLLBACK_SEND", "Ləğv sorğusu göndərilir.", data=rollback_data)
        try:
            response = requests.post(url, data=self._prepare_smartone_payload(rollback_data), timeout=15)
            res = response.json()
            if res.get('status') == 'success':
                self.write({'fiscal_status': 'cancelled'})
                self._smartone_log_console("ROLLBACK_SUCCESS", "Çek kassada ləğv olundu.", data=res)
            else:
                self._smartone_log_console("ROLLBACK_FAILED", "Kassa ləğvi rədd etdi.", success=False, data=res)
        except Exception as e:
            self._smartone_log_console("ROLLBACK_CRITICAL_ERR", str(e), success=False, error_trace=traceback.format_exc())

    def action_cancel(self):
        """ Odoo-da ləğv düyməsinə basıldıqda kassaya sorğu göndərir """
        res = super(SaleOrder, self).action_cancel()
        for order in self:
            if order.fiscal_status == 'sent' and order.fiscal_document_id:
                order.action_smartone_fiscal_rollback()
        return res