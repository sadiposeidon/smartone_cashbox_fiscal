# -*- coding: utf-8 -*-
{
    'name': 'SmartOne Cashbox Fiscal',
    'version': '18.0.1.0.0',
    'category': 'Sales/Payment',
    'summary': 'Fiscal integration for SmartOne Cashbox',
    'author': 'Sadiq Abışov',
    'website': 'https://www.google.com',
    'license': 'LGPL-3',
    'depends': ['base', 'web', 'sale', 'point_of_sale'],
    'data': [
        'views/settings/res_config_settings_views.xml',
        'views/sale/sale_order_views.xml',
    ],
    'installable': True,
    'application': True,
    'license': 'LGPL-3',
}