# -*- coding: utf-8 -*-
import logging
import json
import base64
import hashlib
import requests
import traceback
from datetime import datetime
from odoo import models, fields, api, _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)


# --- MODEL: ÖDƏNİŞ PƏNCƏRƏSİ (REGISTER PAYMENT WIZARD) ---
class AccountPaymentRegister(models.TransientModel):
    _inherit = 'account.payment.register'

    def action_create_payments(self):
        """ Ödəniş tamamlananda (Təsdiqlənəndə) avtomatik kassa çekini göndər """
        res = super(AccountPaymentRegister, self).action_create_payments()
        
        # 1. Ayarlardan avtomatik çapın aktiv olub olmadığını yoxlayırıq
        # 'show_send_button_setting' False (gizli) olması avtomatik çap deməkdir
        show_button = self.env['ir.config_parameter'].sudo().get_param('azsmart_smartone.show_send_button_setting')
        
        if not show_button:
            # Ödəniş üsulunu təyin edirik
            payment_type = 'cashless' if self.journal_id.type == 'bank' else 'cash'
            
            # Bu ödəniş pəncərəsindəki fakturaları tapırıq
            invoices = self.line_ids.mapped('move_id')
            # Fakturalara bağlı təsdiqlənmiş satış sənədlərini tapırıq
            sale_orders = invoices.mapped('invoice_line_ids.sale_line_ids.order_id')
            
            for order in sale_orders:
                if order.fiscal_status == 'draft' and order.state == 'sale':
                    _logger.info(f"🚀 [AZSMART AUTO] {order.name} üçün avtomatik çap başladılır ({payment_type}).")
                    # context vasitəsilə UserError-un qarşısını alırıq ki, ödəniş prosesi bloklanmasın
                    order.with_context(auto_print=True).action_azsmart_smartone_fiscal_sale(payment_method=payment_type)
        
        return res


# --- MODEL: ÖDƏNİŞ TƏSDİQLƏNƏNDƏ AVTOMATİK ÇAP ---
class AccountPayment(models.Model):
    _inherit = 'account.payment'

    def action_post(self):
        """ Ödəniş 'Post' statusuna keçəndə işə düşür """
        res = super(AccountPayment, self).action_post()
        
        show_button = self.env['ir.config_parameter'].sudo().get_param('azsmart_smartone.show_send_button_setting')
        
        if not show_button:
            for payment in self:
                # Odoo 18-də bağlı olan satış sənədlərini tapmaq
                invoices = payment.reconciled_invoice_ids
                sale_orders = invoices.mapped('line_ids.sale_line_ids.order_id')
                
                for order in sale_orders:
                    if order.fiscal_status == 'draft' and order.state == 'sale':
                        _logger.info(f"🚀 [AZSMART AUTO] Ödəniş təsdiqi ilə {order.name} üçün çap tetiklənir.")
                        order.with_context(auto_print=True).action_azsmart_smartone_fiscal_sale()
        return res


class SaleOrder(models.Model):
    _inherit = 'sale.order'

    # --- Sahə Tərifləri ---
    fiscal_document_id = fields.Char(string="Fiskal ID", copy=False)
    fiscal_internal_id = fields.Integer(string="Kassa Daxili ID", copy=False) # documentID (integer olan)
    fiscal_status = fields.Selection([
        ('draft', 'Göndərilməyib'),
        ('sent', 'Fiskallaşdırıldı'),
        ('refunded', 'Geri Qaytarıldı'),
        ('cancelled', 'Ləğv Edildi (Kassa)'),
        ('error', 'Xəta')], default='draft', string="Fiskal Status", copy=False)

    fiscal_qr_link = fields.Char(string="QR Link", compute="_compute_fiscal_qr_link", store=False)



    # --- Ayar Kontrol Sahəsi ---
    show_check_copy_button_setting = fields.Boolean(compute='_compute_show_check_copy_setting')
    show_rollback_button_setting = fields.Boolean(compute='_compute_cashbox_button_settings')
    show_refund_button_setting = fields.Boolean(compute='_compute_cashbox_button_settings')
    show_send_button_setting = fields.Boolean(compute='_compute_cashbox_button_settings')

    @api.depends('fiscal_document_id')
    def _compute_fiscal_qr_link(self):
        """ Fiskal ID-yə əsasən e-kassa monitoring linkini yaradır """
        for order in self:
            if order.fiscal_document_id:
                order.fiscal_qr_link = f"https://monitoring.e-kassa.gov.az/#/index?doc={order.fiscal_document_id}"
            else:
                order.fiscal_qr_link = False

    def _azsmart_smartone_log_console(self, action_name, message, success=True, data=None, error_trace=None):
        """ 
        Professional Terminal Debugging 
        Odoo 18 konsolunda bütün prosesi vizual və detallı əks etdirir.
        """
        marker = "🟢 [SUCCESS]" if success else "🔴 [FAILURE]"
        border = "═" * 100
        log_content = [
            f"\n╔{border}╗",
            f"║ {marker.ljust(20)} | ACTION: {action_name.ljust(75)} ║",
            f"╠{'═' * 100}╣",
            f"║ ZAMAN: {datetime.now().strftime('%Y-%m-%d %H:%M:%S').ljust(91)} ║",
            f"║ MESAJ: {str(message).ljust(92)} ║"
        ]
        
        if data:
            data_str = json.dumps(data, indent=4, ensure_ascii=False)
            log_content.append(f"╠{'─' * 100}╣")
            log_content.append("║ MƏLUMAT (JSON PAYLOAD / RESPONSE):".ljust(101) + "║")
            for line in data_str.split('\n'):
                log_content.append(f"║ {line.ljust(98)} ║")
        
        if error_trace:
            log_content.append(f"╠{'─' * 100}╣")
            log_content.append("║ XƏTA DETALLARI (PYTHON STACK TRACE):".ljust(101) + "║")
            for line in error_trace.split('\n')[-10:]:
                log_content.append(f"║ {line.ljust(98)} ║")

        log_content.append(f"╚{border}╝\n")
        
        final_log = "\n".join(log_content)
        if success:
            _logger.info(final_log)
        else:
            _logger.error(final_log)

    def _get_fiscal_tax_mapping(self, tax_amount):
        """ Odoo vergisini kassa API formatına uyğunlaşdırır """
        amount = round(tax_amount)
        if amount == 18:
            return {"taxName": "ƏDV", "taxPrc": 1800, "taxCode": "4", "calcType": 1}
        elif amount == 0:
            return {"taxName": "ƏDV-dən Azad", "taxPrc": 0, "taxCode": "6", "calcType": 1}
        elif amount == 2:
            return {"taxName": "Sadələşdirilmiş Vergi", "taxPrc": 200, "taxCode": "1", "calcType": 3}
        elif amount == 8:
            return {"taxName": "Sadələşdirilmiş Vergi", "taxPrc": 800, "taxCode": "3", "calcType": 3}
        else:
            return {"taxName": "ƏDV", "taxPrc": int(amount * 100), "taxCode": "4", "calcType": 1}

    def _prepare_azsmart_smartone_payload(self, data_dict):
        """ Məlumatı imzalayıb Base64 formatına salır """
        try:
            merchant_id = self.env['ir.config_parameter'].sudo().get_param('azsmart_smartone.merchant_id') or ""
            json_data = json.dumps(data_dict, ensure_ascii=False, separators=(',', ':'))
            data_b64 = base64.b64encode(json_data.encode('utf-8')).decode('utf-8')
            
            raw_string = (data_b64 + merchant_id).encode('utf-8')
            sha1_hash = hashlib.sha1(raw_string).hexdigest().lower()
            sign_b64 = base64.b64encode(sha1_hash.encode('utf-8')).decode('utf-8')
            
            return {'data': data_b64, 'sign': sign_b64}
        except Exception:
            self._azsmart_smartone_log_console("PAYLOAD_PREP", "İmzalama zamanı xəta!", success=False, error_trace=traceback.format_exc())
            raise


    


    def _compute_show_check_copy_setting(self):
        """ Sistem ayarlarından düymənin aktiv olub-olmadığını yoxlayır """
        show_setting = self.env['ir.config_parameter'].sudo().get_param('azsmart_smartone.show_check_copy')
        for order in self:
            order.show_check_copy_button_setting = bool(show_setting)

    # --- Çek Nüsxəsinin Çapı Metodu ---
    def action_azsmart_smartone_check_copy(self):
        """ /check_copy endpointi - Artıq kəsilmiş çekin nüsxəsini çap edir """
        self.ensure_one()
        get_param = self.env['ir.config_parameter'].sudo().get_param
        ip = get_param('azsmart_smartone.ip')
        port = get_param('azsmart_smartone.port')
        
        if not ip or not port:
            self._azsmart_smartone_log_console("CONFIG_ERR", "Kassa IP və ya Port ayarlanmayıb!", success=False)
            raise UserError(_("Kassa IP və Portu təyin edilməyib!"))

        if not self.fiscal_internal_id:
            self._azsmart_smartone_log_console("CHECK_COPY_SKIP", "Daxili ID yoxdur.", success=False)
            raise UserError(_("Bu sifariş üçün daxili sənəd ID tapılmadı! Öncə çek çap edilməlidir."))

        url = f"http://{ip}:{port}/check_copy"
        copy_data = {"documentID": int(self.fiscal_internal_id)}

        self._azsmart_smartone_log_console("CHECK_COPY_SEND", "Çek nüsxəsi sorğusu göndərilir.", data=copy_data)
        
        try:
            response = requests.post(url, data=self._prepare_azsmart_smartone_payload(copy_data), timeout=10)
            res = response.json()
            
            if res.get('status') == 'success':
                self._azsmart_smartone_log_console("CHECK_COPY_SUCCESS", "Nüsxə uğurla çap olundu.", data=res)
                return {
                    'effect': {
                        'fadeout': 'slow',
                        'message': 'Çek nüsxəsi çap edildi!',
                        'type': 'rainbow_man',
                    }
                }
            else:
                self._azsmart_smartone_log_console("CHECK_COPY_REJECT", "Kassa nüsxəni çap etmədi.", success=False, data=res)
                raise UserError(_("Kassa xətası: %s") % res.get('message', 'Naməlum xəta'))
                
        except Exception as e:
            self._azsmart_smartone_log_console("CHECK_COPY_CRITICAL", str(e), success=False, error_trace=traceback.format_exc())
            raise UserError(_("Kassa ilə əlaqə kəsildi: %s") % str(e))



    @api.depends('name') # və ya digər trigger sahə
    def _compute_cashbox_button_settings(self):
        """ Sistem ayarlarından düymələrin aktivliyini yoxlayır """
        get_param = self.env['ir.config_parameter'].sudo().get_param

        show_copy = get_param('azsmart_show_check_copy')
        show_rollback = get_param('azsmart_show_rollback')
        show_refund = get_param('azsmart_show_refund')
        show_send = get_param('azsmart_show_send')
        
        for order in self:
            # Parametrlər string gəldiyi üçün yoxlama belə olmalıdır
            order.show_check_copy_button_setting = show_copy == 'True'
            order.show_rollback_button_setting = show_rollback == 'True'
            order.show_refund_button_setting = show_refund == 'True'
            
            # Əgər parametr heç təyin olunmayıbsa (İlk quraşdırma), True qəbul etsin
            if show_send is None:
                order.show_send_button_setting = True
            else:
                order.show_send_button_setting = show_send == 'True'


    def action_confirm(self):
        """ 
        Odoo Təsdiq düyməsi. 
        Əgər 'Kassaya Göndər' düyməsi gizlidirfə, təsdiq anında avtomatik fiskal sorğu göndərir.
        """
        # 1. Odoo-nun standart təsdiq prosesini icra et
        res = super(SaleOrder, self).action_confirm()
        
        # 2. Ayarı yoxla
        get_param = self.env['ir.config_parameter'].sudo().get_param
        auto_send = not bool(get_param('azsmart_show_send', default=True))
        
        self._azsmart_smartone_log_console("CONFIRM_TRIGGER", f"Satış təsdiqləndi. Avtomatik göndəriş: {auto_send}")

        if auto_send:
            for order in self:
                # Əgər artıq göndərilməyibsə və status uyğundursa
                if order.fiscal_status != 'sent':
                    self._azsmart_smartone_log_console("AUTO_FISCAL", f"Düymə gizli olduğu üçün {order.name} avtomatik fiskallaşdırılır.")
                    order.action_azsmart_smartone_fiscal_sale()
        
        return res


    def action_azsmart_smartone_fiscal_refund(self):
        """ /refund – Qaytarma hesabatının kassaya göndərilməsi  """
        self.ensure_one()
        
        # Kassa məlumatlarını götürək
        get_param = self.env['ir.config_parameter'].sudo().get_param
        ip = get_param('azsmart_smartone.ip')
        port = get_param('azsmart_smartone.port') or "8008"
        
        if not ip: raise UserError(_("Kassa IP tənzimlənməyib!"))

        url = f"http://{ip}:{port}/refund"
        
        # Məhsulları hazırlayaq
        items = []
        for line in self.order_line:
            items.append({
                "itemId": str(line.product_id.id),
                "itemName": line.product_id.name,
                "itemQty": int(line.product_uom_qty * 1000),
                "itemAmount": int(round(line.price_total * 100)),
                "itemTaxes": [{"taxName": "ƏDV", "taxPrc": 1800}] # Statik nümunə
            })

        refund_data = {
            "docNum": self.name,
            "parentDocNum": self.fiscal_document_id or "", # Əsas satışın fiskal ID-si 
            "amount": int(round(self.amount_total * 100)),
            "currency": "AZN",
            "items": items,
            "payments": {
                "cashAmount": int(round(self.amount_total * 100)),
                "cashlessAmount": 0
            }
        }

        # Sahə tərəfindən tələb olunan loq sistemi
        self._azsmart_smartone_log_console("REFUND_START", "İadə sorğusu göndərilir...", data=refund_data)

        try:
            response = requests.post(url, data=self._prepare_azsmart_smartone_payload(refund_data), timeout=15)
            res = response.json()
            if res.get('status') == 'success':
                self.write({'fiscal_status': 'refunded'})
                self._azsmart_smartone_log_console("REFUND_SUCCESS", "İadə çeki çap olundu.", data=res)
            else:
                self._azsmart_smartone_log_console("REFUND_API_ERR", "Kassa iadəni rədd etdi.", success=False, data=res)
                raise UserError(res.get('message', 'API Xətası'))
        except Exception as e:
            self._azsmart_smartone_log_console("REFUND_CRITICAL", str(e), success=False, error_trace=traceback.format_exc())
            raise UserError(str(e))



    def action_azsmart_smartone_fiscal_sale(self, payment_method='cashless'):
        """ Kassaya satış sorğusu göndərir (Həm manual, həm avtomatik istifadə edilir) """
        self.ensure_one()
        
        conf = self.env['ir.config_parameter'].sudo()
        ip = conf.get_param('azsmart_smartone.ip')
        port = conf.get_param('azsmart_smartone.port', '8008')
        dept_code = conf.get_param('azsmart_smartone.dept_code', '1')
        
        if not ip:
            raise UserError(_("Kassa IP ünvanı sazlanmayıb!"))

        url = f"http://{ip}:{port}/sale"
        
        # Elementlərin (Items) hazırlanması
        items = []
        for line in self.order_line.filtered(lambda l: not l.display_type):
            # Vergi dərəcəsinin təyini (Məsələn: 18% -> taxCode 4)
            tax_code = "4" if any(t.amount == 18 for t in line.tax_id) else "1"
            tax_prc = 1800 if tax_code == "4" else 0
            
            items.append({
                "itemId": str(line.product_id.id),
                "itemName": line.name[:50], # Max 50 simvol
                "itemQty": int(line.product_uom_qty * 1000), # 1.000 = 1 ədəd
                "itemAmount": int(round(line.price_reduce_taxinc * 100)),
                "itemQRCode": "",
                "discount": 0,
                "itemTaxes": [{
                    "taxName": "ƏDV",
                    "taxPrc": tax_prc,
                    "taxCode": tax_code,
                    "calcType": 1
                }]
            })

        # Ödəniş məlumatı
        # payment_method: 'cash' və ya 'cashless'
        total_amount_cents = int(round(self.amount_total * 100))
        
        payload_data = {
            "docNumber": self.name,
            "employeeName": self.env.user.name,
            "deptCode": dept_code,
            "amount": total_amount_cents,
            "currency": "AZN",
            "items": items,
            "payments": {
                "cashAmount": total_amount_cents if payment_method == 'cash' else 0,
                "cashlessAmount": total_amount_cents if payment_method == 'cashless' else 0,
                "otherAmount": 0
            }
        }

        self._azsmart_smartone_log_console("FISCAL_SALE_SEND", f"{self.name} üçün API sorğusu hazırlanır.", data=payload_data)

        try:
            response = requests.post(url, data=self._prepare_azsmart_smartone_payload(payload_data), timeout=15)
            res = response.json()

            if res.get('status') == 'success':
                # Müvəffəqiyyətli cavab
                res_data = res.get('data', {})
                self.write({
                    'fiscal_document_id': res_data.get('shortDocumentID'),
                    'fiscal_internal_id': res_data.get('documentID'),
                    'fiscal_status': 'sent'
                })
                self._azsmart_smartone_log_console("FISCAL_SALE_SUCCESS", "Çek uğurla çap olundu.", data=res)
                
            else:
                # Kassa səviyyəsində xəta
                error_msg = res.get('message', 'Naməlum xəta')
                if "-604" in str(res.get('code')) or "shift duration" in error_msg.lower():
                    error_msg = _("Kassa xətası: Növbə müddəti (24 saat) bitib. Z-Hesabatı (Növbəni bağla) çıxarın!")
                
                self.write({'fiscal_status': 'error'})
                self._azsmart_smartone_log_console("FISCAL_SALE_API_FAIL", "Kassa sorğunu rədd etdi.", success=False, data=res)
                
                # Əgər avtomatik çap deyilsə (manualdırsa) xəta mesajını ekrana çıxar
                if not self.env.context.get('auto_print'):
                    raise UserError(error_msg)

        except Exception as e:
            self.write({'fiscal_status': 'error'})
            self._azsmart_smartone_log_console("FISCAL_SALE_CRITICAL", str(e), success=False, error_trace=traceback.format_exc())
            if not self.env.context.get('auto_print'):
                raise UserError(_("Terminal ilə əlaqə kəsildi: %s") % str(e))



    def action_azsmart_smartone_fiscal_rollback(self):
        """ /rollback endpointi - Çekin ləğvi (API v3.9 uyğun) """
        self.ensure_one()
        get_param = self.env['ir.config_parameter'].sudo().get_param
        ip = get_param('azsmart_smartone.ip')
        port = get_param('azsmart_smartone.port')
        
        if not ip or not port or not self.fiscal_document_id:
            self._azsmart_smartone_log_console("ROLLBACK_SKIP", "Ləğv üçün çatışmayan məlumat (IP və ya Fiskal ID).", success=False)
            return

        url = f"http://{ip}:{port}/rollback"

        # Sənədə əsasən: Rollback zamanı items, payments və amount məcburidir.
        items = []
        for line in self.order_line.filtered(lambda l: not l.display_type):
            item_taxes = [self._get_fiscal_tax_mapping(t.amount) for t in line.tax_id] or [self._get_fiscal_tax_mapping(0)]
            items.append({
                "itemId": str(line.product_id.id),
                "itemName": str(line.product_id.name[:50]),
                "itemQty": int(round(line.product_uom_qty * 1000)),
                "itemAmount": int(round(line.price_total * 100)),
                "discount": int(round((line.price_unit * line.product_uom_qty - line.price_subtotal) * 100)),
                "itemTaxes": item_taxes
            })

        # DİQQƏT: API sənədinin xüsusi tələbi - documentID olaraq fiscalID göndərilməlidir
        rollback_data = {
            "documentID": str(self.fiscal_document_id), 
            "employeeName": str((self.user_id.name or self.env.user.name)[:30]),
            "docNumber": str(self.name),
            "amount": int(round(self.amount_total * 100)),
            "currency": "AZN",
            "reason": "Odoo tərəfindən ləğv edildi",
            "items": items,
            "payments": {
                "cashAmount": int(round(self.amount_total * 100)),
                "cashlessAmount": 0,
                "otherAmount": 0
            }
        }
        
        self._azsmart_smartone_log_console("ROLLBACK_SEND", "Ləğv sorğusu göndərilir.", data=rollback_data)
        try:
            response = requests.post(url, data=self._prepare_azsmart_smartone_payload(rollback_data), timeout=15)
            res = response.json()
            if res.get('status') == 'success':
                self.write({'fiscal_status': 'cancelled'})
                self._azsmart_smartone_log_console("ROLLBACK_SUCCESS", "Çek kassada ləğv olundu.", data=res)
            else:
                self._azsmart_smartone_log_console("ROLLBACK_FAILED", "Kassa ləğvi rədd etdi.", success=False, data=res)
        except Exception as e:
            self._azsmart_smartone_log_console("ROLLBACK_CRITICAL_ERR", str(e), success=False, error_trace=traceback.format_exc())

    def action_cancel(self):
        """ Odoo-da ləğv düyməsinə basıldıqda kassaya sorğu göndərir """
        res = super(SaleOrder, self).action_cancel()
        for order in self:
            if order.fiscal_status == 'sent' and order.fiscal_document_id:
                order.action_azsmart_smartone_fiscal_rollback()
        return res