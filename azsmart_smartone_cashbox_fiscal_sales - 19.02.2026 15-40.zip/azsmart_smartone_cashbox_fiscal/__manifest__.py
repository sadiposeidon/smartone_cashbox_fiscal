# -*- coding: utf-8 -*-
{
    'name': 'AzSmart (SmartOne) Cashbox Fiscal',
    'version': '18.0.1.0.0',
    'category': 'Sales/Payment',
    'summary': 'Fiscal integration for AzSmart (SmartOne) Cashbox',
    "description": '............................',
    'author': 'Sadiq Abışov',
    'license': 'LGPL-3',
    'depends': ['base', 'web', 'sale', 'point_of_sale'],
    'data': [
        'views/settings/res_config_settings_sales_views.xml',
        'views/settings/res_config_settings_dev_views.xml',
        'views/sale/sale_order_views.xml',
    ],
    "images": ['static/description/icon.png'],
    "installable": True,
    "application": True,
    "auto_install": False,
    "license": "LGPL-3",
}