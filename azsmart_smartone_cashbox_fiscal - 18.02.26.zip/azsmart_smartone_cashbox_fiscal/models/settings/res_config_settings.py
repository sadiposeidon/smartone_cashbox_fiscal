# -*- coding: utf-8 -*-
import logging
import time
import json
import base64
import hashlib
import requests
import traceback
from datetime import datetime
from odoo import models, fields, api, _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)

class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    # --- Sahə Tərifləri (Odoo 18 Config Parameters) ---
    azsmart_smartone_ip = fields.Char(string="Kassa IP / URL", config_parameter='azsmart_smartone.ip')
    azsmart_smartone_port = fields.Char(string="Port", config_parameter='azsmart_smartone.port', default="8008")
    azsmart_smartone_merchant_id = fields.Char(string="Merchant ID", config_parameter='azsmart_smartone.merchant_id')
    
    # Departament kodu əlavə edildi (Susmaya görə "1")
    azsmart_smartone_dept_code = fields.Char(
        string="Departament Kodu", 
        config_parameter='azsmart_smartone.dept_code', 
        default="1"
    )

    # API-nin tələbi ilə daxili ID integer olmalıdır, lakin config_parameter string saxlayır.
    azsmart_smartone_document_id = fields.Integer(string="Sənəd ID (Daxili)", config_parameter='azsmart_smartone.document_id', default=0)
    azsmart_smartone_document_ext_id = fields.Char(string="Sənəd Ext ID (Kənar)", config_parameter='azsmart_smartone.document_ext_id', default="1")
    
    azsmart_smartone_timer_active = fields.Boolean(string="Taymer aktiv edilsin?", config_parameter='azsmart_smartone.timer_active', default=True)
    azsmart_smartone_timer = fields.Integer(string="Taymer (san)", config_parameter='azsmart_smartone.timer', default=3)



    azsmart_show_check_copy = fields.Boolean(
        string="Satışda 'Çek Nüsxəsi' düyməsini göstər",
        config_parameter='azsmart_smartone.show_check_copy',
        help="Aktiv edildikdə Satış Sifarişi ekranında təkrar çap düyməsi görünəcək."
    )

    azsmart_show_rollback = fields.Boolean(
        string="Satışda 'Kassa Çekini Ləğv Et' düyməsini göstər",
        config_parameter='azsmart_show_rollback',
        help="Aktiv edildikdə Satış Sifarişi ekranında ləğv düyməsi görünəcək."
    )

    azsmart_show_refund = fields.Boolean(
        string="Satışda 'Məhsul İadəsi' düyməsini göstər",
        config_parameter='azsmart_show_refund',
        help="Aktiv edildikdə Satış Sifarişi ekranında iadə düyməsi görünəcək."
    )

    azsmart_show_send = fields.Boolean(
        string="Satışda 'Kassaya Göndər' düyməsini göstər", 
        config_parameter='azsmart_show_send',
        default=True,
        help="Əgər bu bağlıdırsa, 'Təsdiq edin' (Confirm) düyməsi avtomatik kassa çekini vuracaq."
    )


    _last_log_cache = {}

    def _azsmart_smartone_log_console(self, action_name, message, success=True, data=None, error_trace=None):
        """ Professional Terminal Debugging (Full Process Tracking) """
        current_time = time.time()
        log_key = f"{action_name}_{message}"
        if log_key in self._last_log_cache and current_time - self._last_log_cache[log_key] < 0.1:
            return
        self._last_log_cache[log_key] = current_time

        marker = "✅ SUCCESS" if success else "❌ FAILURE"
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        border = "═" * 100
        
        log_content = [
            f"\n╔{border}╗",
            f"║ {marker.center(98)} ║",
            f"║ ACTION: {action_name.center(90)} ║",
            f"║ TIMESTAMP: {timestamp.center(87)} ║",
            f"╠{'═' * 100}╣",
            f"║ MESSAGE: {str(message)[:90].ljust(90)} ║"
        ]
        
        if data:
            try:
                data_str = json.dumps(data, indent=4, ensure_ascii=False)
                log_content.append(f"╠{' DEBUG DATA '.center(100, '-')}╣")
                for line in data_str.split('\n'):
                    while line:
                        log_content.append(f"║ {line[:96].ljust(98)} ║")
                        line = line[96:]
            except:
                log_content.append(f"║ DATA (RAW): {str(data)[:90].ljust(90)} ║")

        if error_trace:
            log_content.append(f"╠{' ERROR TRACEBACK '.center(100, '-')}╣")
            for line in error_trace.split('\n'):
                if line.strip():
                    log_content.append(f"║ {line[:96].ljust(98)} ║")
            
        log_content.append(f"╚{border}╝\n")
        
        final_log = "\n".join(log_content)
        if success:
            _logger.info(final_log)
        else:
            _logger.error(final_log)

    def _prepare_azsmart_smartone_payload(self, data_dict):
        """ azsmart_smartone API v3.9 üçün data və sign hazırlayır """
        self._azsmart_smartone_log_console("PAYLOAD_GEN", "Payload hazırlanır...", data=data_dict)
        try:
            merchant_id = self.azsmart_smartone_merchant_id or ""
            data_dict["merchant_id"] = merchant_id
            
            # 1. Kompakt JSON
            json_data = json.dumps(data_dict, separators=(',', ':'), ensure_ascii=False)
            
            # 2. Base64 Encode
            data_b64 = base64.b64encode(json_data.encode('utf-8')).decode('utf-8')
            
            # 3. SHA1 Hash
            raw_string = data_b64 + merchant_id
            sha1_hash = hashlib.sha1(raw_string.encode('utf-8')).hexdigest().lower()
            
            # 4. Sign Base64 Encode
            sign_b64 = base64.b64encode(sha1_hash.encode('utf-8')).decode('utf-8')
            
            payload = {'data': data_b64, 'sign': sign_b64}
            self._azsmart_smartone_log_console("PAYLOAD_READY", "Payload uğurla imzalandı.", data=payload)
            return payload
        except Exception as e:
            self._azsmart_smartone_log_console("PAYLOAD_ERR", f"İmzalama xətası: {str(e)}", success=False, error_trace=traceback.format_exc())
            return None

    def action_azsmart_smartone_test_connection(self):
        """ /get_info (PING) testi """
        self._azsmart_smartone_log_console("TEST_CONN_START", "Bağlantı testi başladılır...")
        
        if not self.azsmart_smartone_ip or not self.azsmart_smartone_merchant_id:
            msg = "IP və ya Merchant ID boşdur!"
            self._azsmart_smartone_log_console("TEST_CONN_VALIDATION", msg, success=False)
            raise UserError(_(msg))

        url = f"http://{self.azsmart_smartone_ip}:{self.azsmart_smartone_port}/get_info"
        payload = self._prepare_azsmart_smartone_payload({
            "ping": True,
            "timestamp": datetime.now().isoformat()
        })

        try:
            self._azsmart_smartone_log_console("TEST_CONN_HTTP", f"URL: {url} sorğu göndərilir...")
            response = requests.post(url, params=payload, data=payload, timeout=10)
            
            if response.status_code == 200:
                res_data = response.json()
                if res_data.get('status') == 'success':
                    self._azsmart_smartone_log_console("TEST_CONN_SUCCESS", "Kassa aktivdir.", data=res_data)
                    return {
                        'type': 'ir.actions.client',
                        'tag': 'display_notification',
                        'params': {
                            'title': _('Uğurlu'),
                            'message': _('Bağlantı quruldu: %s') % res_data.get('company_name', 'OK'),
                            'type': 'success',
                        }
                    }
                else:
                    self._azsmart_smartone_log_console("TEST_CONN_API_ERR", "API xəta qaytardı.", success=False, data=res_data)
                    raise UserError(_("Kassa Xətası: %s") % res_data.get('message'))
            else:
                self._azsmart_smartone_log_console("TEST_CONN_HTTP_ERR", f"HTTP Kod: {response.status_code}", success=False)
                raise UserError(_("Server cavab vermir (HTTP %s)") % response.status_code)
        except Exception as e:
            self._azsmart_smartone_log_console("TEST_CONN_CRITICAL", str(e), success=False, error_trace=traceback.format_exc())
            raise UserError(_("Əlaqə xətası: %s") % str(e))

    def action_azsmart_smartone_check_status(self):
        """ /check_status endpointinə sorğu """
        doc_id = int(self.azsmart_smartone_document_id or 0)
        ext_id = str(self.azsmart_smartone_document_ext_id or "1")
        
        self._azsmart_smartone_log_console("CHECK_STATUS_START", f"ID: {doc_id} / ExtID: {ext_id} sorğulanır...")
        
        url = f"http://{self.azsmart_smartone_ip}:{self.azsmart_smartone_port}/check_status"
        payload = self._prepare_azsmart_smartone_payload({
            "documentID": doc_id,
            "documentExtID": ext_id
        })

        try:
            headers = {'Content-Type': 'application/x-www-form-urlencoded'}
            response = requests.post(url, params=payload, data=payload, headers=headers, timeout=10)
            
            if response.status_code == 200:
                res_data = response.json()
                if res_data.get('status') == 'success':
                    self._azsmart_smartone_log_console("STATUS_SUCCESS", "Məlumat alındı.", data=res_data)
                    return {
                        'type': 'ir.actions.client',
                        'tag': 'display_notification',
                        'params': {
                            'title': _('Kassa Statusu'),
                            'message': _('Vəziyyət: %s') % res_data.get('state', 'N/A'),
                            'type': 'info',
                        }
                    }
                else:
                    self._azsmart_smartone_log_console("STATUS_API_FAIL", "API status xətası.", success=False, data=res_data)
                    raise UserError(_("Kassa xətası: %s") % res_data.get('message'))
            else:
                self._azsmart_smartone_log_console("STATUS_HTTP_ERR", f"HTTP: {response.status_code}", success=False)
                raise UserError(_("HTTP Xətası: %s") % response.status_code)
        except Exception as e:
            self._azsmart_smartone_log_console("STATUS_CRITICAL", str(e), success=False, error_trace=traceback.format_exc())
            raise UserError(_("Status xətası: %s") % str(e))

    # Əlavə edildi: 18.02.25
    def action_azsmart_smartone_open_shift(self):
        """ /open_shift - Növbəni cari kassir adı ilə açır """
        self._azsmart_smartone_log_console("OPEN_SHIFT", "Növbə açılışı başladılır...")
        
        # API Sənədinə uyğun sahələr
        payload_data = {
            "employeeName": self.env.user.name, # Odoo-dakı cari istifadəçi (Kassir)
            "departmentCode": self.azsmart_smartone_dept_code or "1"
        }
        
        url = f"http://{self.azsmart_smartone_ip}:{self.azsmart_smartone_port}/open_shift"
        payload = self._prepare_azsmart_smartone_payload(payload_data)
        
        try:
            response = requests.post(url, data=payload, timeout=15)
            if response.status_code == 200:
                res_data = response.json()
                if res_data.get('status') == 'success':
                    self._azsmart_smartone_log_console("OPEN_SHIFT_SUCCESS", "Növbə uğurla açıldı.", data=res_data)
                    return True
                else:
                    self._azsmart_smartone_log_console("OPEN_SHIFT_API_FAIL", "API xətası qaytardı.", success=False, data=res_data)
                    raise UserError(res_data.get('message', 'Kassa tətbiqi əməliyyatı rədd etdi.'))
            else:
                self._azsmart_smartone_log_console("OPEN_SHIFT_HTTP_ERR", f"HTTP {response.status_code}", success=False)
                raise UserError(_("Server cavab vermir (HTTP %s)") % response.status_code)
        except Exception as e:
            self._azsmart_smartone_log_console("OPEN_SHIFT_CRITICAL", str(e), success=False, error_trace=traceback.format_exc())
            raise UserError(str(e))

    # Əlavə edildi: 18.02.25
    def action_azsmart_smartone_close_shift(self):
        """ /close_shift - Növbəni cari kassir adı ilə bağlayır """
        self._azsmart_smartone_log_console("CLOSE_SHIFT", "Növbə bağlanışı başladılır...")
        
        # API Sənədinə uyğun sahələr
        payload_data = {
            "employeeName": self.env.user.name, # Odoo-dakı cari istifadəçi (Kassir)
            "departmentCode": self.azsmart_smartone_dept_code or "1"
        }
        
        url = f"http://{self.azsmart_smartone_ip}:{self.azsmart_smartone_port}/close_shift"
        payload = self._prepare_azsmart_smartone_payload(payload_data)
        
        try:
            response = requests.post(url, data=payload, timeout=15)
            if response.status_code == 200:
                res_data = response.json()
                if res_data.get('status') == 'success':
                    self._azsmart_smartone_log_console("CLOSE_SHIFT_SUCCESS", "Növbə uğurla bağlandı.", data=res_data)
                    return True
                else:
                    self._azsmart_smartone_log_console("CLOSE_SHIFT_API_FAIL", "API xətası qaytardı.", success=False, data=res_data)
                    raise UserError(res_data.get('message', 'Kassa tətbiqi əməliyyatı rədd etdi.'))
            else:
                self._azsmart_smartone_log_console("CLOSE_SHIFT_HTTP_ERR", f"HTTP {response.status_code}", success=False)
                raise UserError(_("Server cavab vermir (HTTP %s)") % response.status_code)
        except Exception as e:
            self._azsmart_smartone_log_console("CLOSE_SHIFT_CRITICAL", str(e), success=False, error_trace=traceback.format_exc())
            raise UserError(str(e))

    # Əlavə edildi: 18.02.25
    def action_azsmart_smartone_check_shift(self):
        """ /check_shift - Mövcud növbənin vəziyyətini yoxlayır """
        self._azsmart_smartone_log_console("CHECK_SHIFT_START", "Növbə statusu yoxlanılır...")
        
        url = f"http://{self.azsmart_smartone_ip}:{self.azsmart_smartone_port}/check_shift"
        payload = self._prepare_azsmart_smartone_payload({
            "timestamp": datetime.now().isoformat()
        })

        try:
            response = requests.post(url, data=payload, timeout=10)
            if response.status_code == 200:
                res_data = response.json()
                if res_data.get('status') == 'success':
                    is_open = res_data.get('isShiftOpen', 'false') == 'true'
                    status_msg = "AÇIQ" if is_open else "BAĞLI"
                    self._azsmart_smartone_log_console("CHECK_SHIFT_SUCCESS", f"Növbə statusu: {status_msg}", data=res_data)
                    
                    return {
                        'type': 'ir.actions.client',
                        'tag': 'display_notification',
                        'params': {
                            'title': _('Növbə Statusu'),
                            'message': _('Kassa növbəsi hazırda %s vəziyyətindədir.') % status_msg,
                            'type': 'info',
                            'sticky': False,
                        }
                    }
                else:
                    self._azsmart_smartone_log_console("CHECK_SHIFT_API_FAIL", "Status yoxlanıla bilmədi.", success=False, data=res_data)
                    raise UserError(_("Kassa Xətası: %s") % res_data.get('message'))
            else:
                self._azsmart_smartone_log_console("CHECK_SHIFT_HTTP_ERR", f"HTTP {response.status_code}", success=False)
                raise UserError(_("Server cavab vermir (HTTP %s)") % response.status_code)
        except Exception as e:
            self._azsmart_smartone_log_console("CHECK_SHIFT_CRITICAL", str(e), success=False, error_trace=traceback.format_exc())
            raise UserError(str(e))

    def execute(self):
        """ Ayarlar yadda saxlanılan zaman """
        res = super(ResConfigSettings, self).execute()
        self._azsmart_smartone_log_console("CONFIG_SAVE", "Ayarlar Odoo verilənlər bazasında yeniləndi.")
        return res