/** @odoo-module **/

import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";

async function smartoneAutoPrint(env, action) {
    const { params } = action;
    const orm = env.services.orm;
    const smartone = env.services.smartone_service;
    const notification = env.services.notification;

    console.log(`%c🚀 [SmartOne] Avtomatik Çap Başladı: ${params.name}`, "color: #3498db; font-weight: bold;");

    try {
        // 1. Konfiqurasiyanı alırıq
        const config = await orm.call("res.config.settings", "get_smartone_config", [[]]);
        const url = smartone.getFullUrl(config.smartone_url, config.smartone_port, "sale");

        // 2. Payload hazırlayırıq (Dəqiq backend datası ilə)
        const payload = {
            "docNumber": params.name,
            "amount": Math.round(params.amount_total * 100), // Qəpiklə
            "employeeName": env.session?.name || "Odoo Admin",
            "payments": {
                "cashAmount": 0,
                "cashlessAmount": Math.round(params.amount_total * 100)
            }
        };

        // 3. Kassaya sorğu
        const res = await smartone.sendRequest(url, payload, config.smartone_merchant_id);

        if (res && res.fiscalID) {
            // 4. Nəticəni bazaya yazırıq
            await orm.write("sale.order", [params.res_id], {
                smartone_fiscal_id: res.fiscalID,
                smartone_fiscal_num: res.documentID,
                smartone_sent: true
            });
            notification.add(`${params.name} üçün kassa çeki çap olundu.`, { type: "success" });
        }
    } catch (err) {
        console.error("❌ SmartOne Avtomatika Xətası:", err);
        notification.add("Kassa çapı uğursuz oldu: " + err.message, { type: "danger" });
    }
}

// Action registry-ə əlavə edirik
registry.category("actions").add("smartone_auto_print", smartoneAutoPrint);