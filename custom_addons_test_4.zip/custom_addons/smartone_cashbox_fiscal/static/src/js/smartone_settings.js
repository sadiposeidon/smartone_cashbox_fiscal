/** @odoo-module **/

import { patch } from "@web/core/utils/patch";
import { SettingsFormController } from "@web/webclient/settings_form_view/settings_form_controller";
import { FormController } from "@web/views/form/form_controller"; 
import { useService } from "@web/core/utils/hooks";
import { useEffect } from "@odoo/owl";

// --- 1. AYARLAR EKRANI ÜÇÜN PATCH ---
patch(SettingsFormController.prototype, {
    setup() {
        super.setup(...arguments);
        this.notification = useService("notification");
        this.orm = useService("orm");
        this.smartone = useService("smartone_service");

        useEffect(() => {
            const el = document.querySelector(".o_settings_container");
            if (!el) return;
            const handleClicks = async (ev) => {
                const btn = ev.target.closest(".js_smartone_check_device, .js_smartone_check_status");
                if (btn) {
                    const isCheckDevice = btn.classList.contains("js_smartone_check_device");
                    await this.executeAction(isCheckDevice ? "get_info" : "check_status");
                }
            };
            el.addEventListener("click", handleClicks);
            return () => el.removeEventListener("click", handleClicks);
        }, () => []);
    },

    async executeAction(endpoint) {
        const d = this.model.root.data;
        if (!d.smartone_url || !d.smartone_merchant_id) {
            return this.notification.add("URL və Merchant ID doldurulmalıdır!", { type: "danger" });
        }
        const url = this.smartone.getFullUrl(d.smartone_url, d.smartone_port, endpoint);
        const payload = { "employeeName": "Odoo Admin", "documentExtID": d.smartone_document_ext_id || "" };
        try {
            const res = await this.smartone.sendRequest(url, payload, d.smartone_merchant_id);
            if (this.orm && typeof this.orm.call === 'function') {
                await this.orm.call("res.config.settings", "log_smartone_debug", [res]);
            }
            this.notification.add("Sorğu tamamlandı (Console-a baxın)", { type: "info" });
        } catch (e) {
            this.notification.add("Bağlantı xətası!", { type: "danger" });
        }
    }
});

// --- 2. SİFARİŞ FORMU ÜÇÜN PATCH (Təhlükəsiz Data Oxuma) ---
patch(FormController.prototype, {
    setup() {
        super.setup(...arguments);
        this.smartone = useService("smartone_service");
        this.orm = useService("orm");
        this.notification = useService("notification");
    },

    async beforeExecuteActionButton(clickAction) {
        const actionName = clickAction.name;
        const resModel = this.model.root.resModel;
        
        // Sənəd datasını tam şəkildə alırıq
        const data = this.model.root.data;

        // A. SATIŞ TƏSDİQLƏNMƏSİ (action_confirm)
        if (actionName === "action_confirm" && resModel === "sale.order") {
            const result = await super.beforeExecuteActionButton(...arguments);
            
            console.log("%c📡 [SmartOne] Sale Confirm tutuldu. Frontend prosesi...", "color: #2ecc71; font-weight: bold;");
            
            // Backend bitdikdən sonra məlumatları yenidən oxumaq üçün timeout və ya ən son datanı gözləyirik
            await this._handleSaleOrderFiscal(data);
            
            return result;
        }

        // B. DÜYMƏLƏR (Refund, Rollback, Copy)
        const targetButtons = ["action_smartone_refund", "action_smartone_rollback", "action_smartone_check_copy"];
        if (targetButtons.includes(actionName) && (resModel === "pos.order" || resModel === "sale.order")) {
            try {
                const config = await this.orm.call("res.config.settings", "get_smartone_config", [[]]);
                const endpoint = actionName.replace('action_smartone_', '');

                const payload = { 
                    "employeeName": this.env.session?.name || "Odoo Admin",
                    "documentID": data.smartone_fiscal_num || "",
                    "docNumber": data.name || "N/A"
                };

                const url = this.smartone.getFullUrl(config.smartone_url, config.smartone_port, endpoint);
                await this.smartone.sendRequest(url, payload, config.smartone_merchant_id);
                this.notification.add("Əməliyyat tamamlandı.", { type: "success" });
            } catch (e) {
                console.error("SmartOne JS Button Error:", e);
            }
            return false; 
        }

        return super.beforeExecuteActionButton(...arguments);
    },

    async _handleSaleOrderFiscal(data) {
        try {
            // "undefined" xətası olmaması üçün data.name yoxdursa bir az gözlə və ya sənəd datasını yenidən götür
            const orderName = data?.name || "Draft Order";
            const amountTotal = data?.amount_total || 0;
            const employee = this.env.session?.name || "Odoo Admin";

            console.log(`%c🚀 Göndərilən Data: Name: ${orderName}, Amount: ${amountTotal}`, "color: #3498db;");

            const config = await this.orm.call("res.config.settings", "get_smartone_config", [[]]);
            const url = this.smartone.getFullUrl(config.smartone_url, config.smartone_port, "sale");
            
            const payload = {
                "docNumber": orderName,
                "amount": Math.round(amountTotal * 100),
                "employeeName": employee,
                "payments": { 
                    "cashAmount": 0,
                    "cashlessAmount": Math.round(amountTotal * 100) 
                }
            };

            const res = await this.smartone.sendRequest(url, payload, config.smartone_merchant_id);
            
            if (res && res.fiscalID) {
                // Sənəd ID-sini düzgün götürdüyümüzdən əmin oluruq
                const orderId = this.model.root.resId || data.id;
                await this.orm.write("sale.order", [orderId], {
                    smartone_fiscal_id: res.fiscalID,
                    smartone_fiscal_num: res.documentID,
                    smartone_sent: true
                });
                this.notification.add("Fiskal çek çap edildi.", { type: "success" });
            }
        } catch (err) {
            console.error("❌ Avtomatik kassa xətası (Detallı):", err);
            this.notification.add("Kassa xətası: " + err.message, { type: "danger" });
        }
    }
});