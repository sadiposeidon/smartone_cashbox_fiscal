# -*- coding: utf-8 -*-
from odoo import models, fields, api
import logging

_logger = logging.getLogger(__name__)

class SaleOrder(models.Model):
    _inherit = 'sale.order'

    smartone_fiscal_id = fields.Char(string="Fiskal ID", readonly=True, copy=False)
    smartone_fiscal_num = fields.Char(string="Fiskal Nömrə", readonly=True, copy=False)
    smartone_sent = fields.Boolean(string="Kassaya Göndərilib", default=False, copy=False)

    def action_confirm(self):
        """ Sifariş təsdiqlənir və JS-ə kassa sorğusu üçün trigger göndərilir """
        res = super(SaleOrder, self).action_confirm()
        
        _logger.info(f"✅ [SmartOne] {self.name} təsdiqləndi. JS-ə Client Action göndərilir.")
        
        # Bu hissə frontend-də (JS) xüsusi funksiyanı işə salacaq
        return {
            'type': 'ir.actions.client',
            'tag': 'smartone_auto_print',
            'params': {
                'res_id': self.id,
                'name': self.name,
                'amount_total': self.amount_total,
            }
        }