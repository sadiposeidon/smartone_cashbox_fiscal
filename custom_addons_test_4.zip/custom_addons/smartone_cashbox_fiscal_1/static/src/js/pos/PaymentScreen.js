/** @odoo-module **/

import { patch } from "@web/core/utils/patch";
import { PaymentScreen } from "@point_of_sale/app/screens/payment_screen/payment_screen";
import { TicketScreen } from "@point_of_sale/app/screens/ticket_screen/ticket_screen";
import { PosOrder } from "@point_of_sale/app/models/pos_order";
import { FormController } from "@web/views/form/form_controller"; 
import { useService } from "@web/core/utils/hooks";

// =============================================================================
// 1. SİFARİŞ MODELİNİ PATCH EDİRİK (DATA PERSISTENCY)
// =============================================================================
patch(PosOrder.prototype, {
    setup(obj) {
        super.setup(...arguments);
        // Fiskal ID-lərin brauzer cache-də itməməsi üçün mütləq inisializasiya
        this.smartone_fiscal_id = this.smartone_fiscal_id || false;
        this.smartone_fiscal_num = this.smartone_fiscal_num || false;
        this.smartone_sent = this.smartone_sent || false;
        
        console.log("%c[MODEL] PosOrder SmartOne persistent fields initialized.", "color: #9e9e9e; font-style: italic;");
    },
    export_as_JSON() {
        const json = super.export_as_JSON(...arguments);
        // Odoo Server-ə ötürülən JSON datası
        json.smartone_fiscal_id = this.smartone_fiscal_id;
        json.smartone_fiscal_num = this.smartone_fiscal_num;
        return json;
    },
    export_for_printing() {
        const result = super.export_for_printing(...arguments);
        // Qəbz çapı üçün lazım olan dataya əlavə edilir
        result.smartone_fiscal_id = this.smartone_fiscal_id;
        result.smartone_fiscal_num = this.smartone_fiscal_num;
        return result;
    }
});

// =============================================================================
// 2. ÖDƏNİŞ EKRANINI PATCH EDİRİK (CORE LOGIC)
// =============================================================================
patch(PaymentScreen.prototype, {
    setup() {
        super.setup(...arguments);
        this.smartone = useService("smartone_service");
        this.notification = useService("notification");
        this.orm = useService("orm");
        this._smartoneConfig = null;

        console.log("%c🚀 [SMARTONE] Professional Debug System Online!", "color: white; background: #673ab7; padding: 5px; border-radius: 4px; font-weight: bold;");
    },

    /**
     * PEŞƏKAR RƏNGLİ DEBUG LOG SİSTEMİ
     * Bütün API sorğularını vizual olaraq qruplaşdırır.
     */
    _smartLog(type, action, data, isError = false) {
        const styles = {
            request: "background: #2196F3; color: white; font-weight: bold; padding: 3px 6px; border-left: 10px solid #0d47a1;",
            response: "background: #4CAF50; color: white; font-weight: bold; padding: 3px 6px; border-left: 10px solid #1b5e20;",
            error: "background: #F44336; color: white; font-weight: bold; padding: 3px 6px; border-left: 10px solid #b71c1c;",
            info: "background: #FF9800; color: white; font-weight: bold; padding: 3px 6px; border-left: 10px solid #e65100;"
        };
        const style = isError ? styles.error : styles[type] || styles.info;
        const icon = isError ? "❌" : (type === 'request' ? "📡" : "✅");
        
        console.groupCollapsed(`%c ${icon} SMARTONE | ${action.toUpperCase()} | ${new Date().toLocaleTimeString()} `, style);
        if (data) {
            if (typeof data === 'object') {
                console.table(data);
                console.log("Full Object Data:", data);
            } else {
                console.log("Message Details:", data);
            }
        }
        console.groupEnd();
    },

    /**
     * Sifariş təsdiq edilməzdən əvvəl kassa API-ni işə salır.
     */
    async validateOrder(isForceValidate) {
        this._smartLog('info', 'Validayasiya', "Sifariş üçün fiskal yoxlanış başlayır...");
        const order = this.pos.get_order();
        
        if (!order) {
            this._smartLog('error', 'Critical Error', "Order obyekti mövcud deyil!", true);
            return super.validateOrder(...arguments);
        }

        // Təkrar fiskallaşmanın qarşısını alırıq
        if (order.smartone_sent || order.smartone_fiscal_id) {
            this._smartLog('info', 'Skip', "Sifariş artıq fiskallaşıb. Proses Odoo ilə davam edir.");
            return super.validateOrder(...arguments);
        }

        // Mənfi məbləğlər üçün fiskal sorğu atılmır
        if (order.get_total_with_tax() <= 0) {
             this._smartLog('info', 'Notice', "Məbləğ sıfırdır, kassa sorğusu atılmır.");
             return super.validateOrder(...arguments);
        }

        try {
            const success = await this.sendToSmartOne(order);
            
            if (success) {
                order.smartone_sent = true;
                this._smartLog('info', 'Validation', "Kassa sorğusu uğurla cavablandığı üçün Odoo təsdiqinə icazə verildi.");

                // Konfiqurasiyanı təzələyirik
                this._smartoneConfig = await this.orm.call("res.config.settings", "get_smartone_config", [[]]);
                const config = this._smartoneConfig;

                // CHECKBOX DÜZƏLİŞİ: Tip yoxlanışı ilə tam dəqiqləşdirmə
                const timerEnabled = (config.smartone_enable_timer === true || config.smartone_enable_timer === 'True');
                const timerDelay = config.smartone_check_status_timer || 3;

                this._smartLog('info', 'Timer Configuration', {
                    "Enabled": timerEnabled,
                    "Delay": timerDelay + " seconds"
                });

                // Əgər checkbox seçilidirsə Timer işləyəcək
                if (timerEnabled) {
                    this._smartLog('info', 'Timer Start', `Gözləmə müddəti: ${timerDelay} saniyə.`);
                    setTimeout(async () => {
                        try {
                            const url = this.smartone.getFullUrl(config.smartone_url, config.smartone_port, "check_status");
                            const payload = {
                                documentID: order.smartone_fiscal_num || "",
                                employeeName: this.pos.get_cashier().name,
                            };
                            
                            this._smartLog('request', 'Auto Status Check', payload);
                            const res = await this.smartone.sendRequest(url, payload, config.smartone_merchant_id);
                            
                            if (res) {
                                this._smartLog('response', 'Status Results', res);
                                this.notification.add("SmartOne: Avtomatik status sorğusu uğurludur.", { type: "info" });
                            }
                        } catch (e) {
                            this._smartLog('error', 'Timer Process Error', e, true);
                        }
                    }, timerDelay * 1000);
                }

            } else {
                this._smartLog('error', 'Validation Failure', "Kassa cavab vermədi, lakin validasiya məcburidir.", true);
            }
        } catch (e) {
            this._smartLog('error', 'Global Exception', e.message || e, true);
        }

        return super.validateOrder(...arguments);
    },

    /**
     * SALE (Satış) API Sorğusu
     */
    async sendToSmartOne(order) {
        try {
            this._smartLog('info', 'API Setup', "Kassa ayarları bazadan çəkilir...");
            this._smartoneConfig = await this.orm.call("res.config.settings", "get_smartone_config", [[]]);
            const config = this._smartoneConfig;
            
            // Məhsulları API formatına çeviririk
            const items = order.lines.map(line => {
                let taxPrc = 1800; // Default 18%
                if (line.tax_ids.length > 0) {
                    const tax = this.pos.models["account.tax"].get(line.tax_ids[0]);
                    if (tax) taxPrc = tax.amount * 100;
                }
                return {
                    "itemId": line.product_id.id.toString(),
                    "itemName": line.product_id.display_name || line.product_id.name,
                    "itemQty": Math.round(line.qty * 1000),
                    "itemAmount": Math.round(line.price_subtotal_incl * 100),
                    "itemTaxes": [{ "taxName": "ƏDV", "taxCode": "4", "taxPrc": taxPrc, "calcType": 1 }]
                };
            });

            // Ödənişləri ayırırıq
            let cashVal = 0, cardVal = 0;
            for (const p of order.payment_ids) {
                if (p.payment_method_id.type === 'cash') cashVal += p.amount;
                else cardVal += p.amount;
            }

            const payload = {
                "docNumber": order.name,
                "amount": Math.round(order.get_total_with_tax() * 100),
                "currency": "AZN",
                "employeeName": this.pos.get_cashier().name,
                "items": items,
                "payments": {
                    "cashAmount": Math.round(cashVal * 100),
                    "cashlessAmount": Math.round(cardVal * 100)
                }
            };

            const url = this.smartone.getFullUrl(config.smartone_url, config.smartone_port, "sale");
            this._smartLog('request', 'SALE Transaction', { url, payload });

            const res = await this.smartone.sendRequest(url, payload, config.smartone_merchant_id);
            this._smartLog('response', 'SALE Completion', res);

            if (res?.fiscalID) {
                order.smartone_fiscal_id = res.fiscalID;
                order.smartone_fiscal_num = res.documentID;
                this.notification.add(`Əməliyyat Uğurlu! Fiskal ID: ${res.fiscalID}`, { type: "success" });
                return true;
            }
            return false;
        } catch (error) {
            this._smartLog('error', 'Sale API CRITICAL ERROR', error.message || error, true);
            return false;
        }
    },

    // -------------------------------------------------------------------------
    // FRONTEND DÜYMƏLƏRİ
    // -------------------------------------------------------------------------
    async action_smartone_refund() {
        this._smartLog('info', 'Action', "Geri qaytarma (Refund) düyməsi basıldı.");
        const o = this.pos.get_order();
        if (!o?.smartone_fiscal_num) {
            this.notification.add("Fiskal nömrə tapılmadı!", { type: "danger" });
            return;
        }
        try {
            const cfg = await this.orm.call("res.config.settings", "get_smartone_config", [[]]);
            const url = this.smartone.getFullUrl(cfg.smartone_url, cfg.smartone_port, "refund");
            const res = await this.smartone.sendRequest(url, { 
                "documentID": o.smartone_fiscal_num, 
                "employeeName": this.pos.get_cashier().name 
            }, cfg.smartone_merchant_id);
            if (res) this.notification.add("Geri qaytarma icra edildi.", { type: "success" });
        } catch (e) { this._smartLog('error', 'Refund UI Error', e, true); }
    }
});

// =============================================================================
// 3. TICKET SCREEN (HISTORY) PATCH
// =============================================================================
patch(TicketScreen.prototype, {
    setup() {
        super.setup(...arguments);
        this.smartone = useService("smartone_service");
        this.orm = useService("orm");
        this.notification = useService("notification");
    },
    async _executeSmartoneAction(order, action) {
        try {
            const config = await this.orm.call("res.config.settings", "get_smartone_config", [[]]);
            const url = this.smartone.getFullUrl(config.smartone_url, config.smartone_port, action);
            const res = await this.smartone.sendRequest(url, { 
                "documentID": order.smartone_fiscal_num || "", 
                "employeeName": this.pos.get_cashier().name 
            }, config.smartone_merchant_id);
            if (res) this.notification.add(`Əməliyyat (${action}) tamamlandı.`, { type: "success" });
        } catch (e) { console.error("TicketScreen API Error:", e); }
    }
});

// =============================================================================
// 4. FORM CONTROLLER (BACKEND SYNC)
// =============================================================================
patch(FormController.prototype, {
    setup() {
        super.setup(...arguments);
        this.smartone = useService("smartone_service");
        this.orm = useService("orm");
        this.notification = useService("notification");
    },
    async beforeExecuteActionButton(clickParams) {
        const triggers = ['action_smartone_refund', 'action_smartone_rollback', 'action_smartone_check_copy'];
        
        if (triggers.includes(clickParams.name)) {
            console.log(`%c🚫 [SMARTONE] Backend Python RPC intercepted: ${clickParams.name}`, "color: white; background: #d32f2f; font-weight: bold;");
            
            const record = this.model.root;
            const action = clickParams.name.replace('action_smartone_', '');

            try {
                const config = await this.orm.call("res.config.settings", "get_smartone_config", [[]]);
                const url = this.smartone.getFullUrl(config.smartone_url, config.smartone_port, action);
                
                await this.smartone.sendRequest(url, {
                    "documentID": record.data.smartone_fiscal_num || "",
                    "employeeName": record.data.user_id ? record.data.user_id[1] : "Administrator"
                }, config.smartone_merchant_id);

                this.notification.add("Backend əməliyyatı uğurludur.", { type: "success" });
            } catch (e) {
                this.notification.add("Bağlantı xətası!", { type: "danger" });
            }

            // Python tərəfinə sorğu getməsini dayandırırıq (Yalnız JS API işləyir)
            return false; 
        }
        return super.beforeExecuteActionButton(...arguments);
    }
});