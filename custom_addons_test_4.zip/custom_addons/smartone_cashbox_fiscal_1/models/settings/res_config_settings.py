# -*- coding: utf-8 -*-
import logging
from odoo import models, fields, api
from odoo.tools import str2bool

_logger = logging.getLogger(__name__)

# =====================================================
#   SETTINGS MODEL - SMARTONE FISCAL
# =====================================================
class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    smartone_url = fields.Char(
        string="URL / IP",
        config_parameter='smartone_cashbox_fiscal.smartone_url',
        help="Kassa aparatının şəbəkə ünvanı (məs: http://192.168.1.50)"
    )

    smartone_port = fields.Char(
        string="PORT",
        config_parameter='smartone_cashbox_fiscal.smartone_port',
        default="8008"
    )

    smartone_merchant_id = fields.Char(
        string="MERCHANT ID",
        config_parameter='smartone_cashbox_fiscal.smartone_merchant_id'
    )

    smartone_document_ext_id = fields.Char(
        string="Document External ID",
        config_parameter='smartone_cashbox_fiscal.smartone_document_ext_id'
    )

    smartone_enable_timer = fields.Boolean(
        string="Timeri aktiv et",
        config_parameter='smartone_cashbox_fiscal.smartone_enable_timer',
    )

    smartone_check_status_timer = fields.Integer(
        string="CHECK STATUS TIMER",
        config_parameter='smartone_cashbox_fiscal.smartone_check_status_timer',
        default=3
    )

    @api.model
    def log_smartone_debug(self, data):
        """Frontend-dən gələn debug məlumatlarını server loguna yazır"""
        _logger.info("=== [DEBUG] SMARTONE API TRACE START ===")
        _logger.info(data)
        _logger.info("=== [DEBUG] SMARTONE API TRACE END ===")
        return True

    @api.model
    def get_smartone_config(self, args=None):
        """
        Mərkəzi konfiqurasiya oxuyucusu.
        Checkbox problemini həll etmək üçün get_param defaultu 'False' təyin edildi.
        """
        params = self.env['ir.config_parameter'].sudo()
        
        # DÜZƏLİŞ: Əgər parametr yoxdursa, 'False' stringi qaytarırıq ki, str2bool düzgün işləsin.
        raw_timer_val = params.get_param('smartone_cashbox_fiscal.smartone_enable_timer', 'False')
        
        config_data = {
            'smartone_url': params.get_param('smartone_cashbox_fiscal.smartone_url', ''),
            'smartone_port': params.get_param('smartone_cashbox_fiscal.smartone_port', '8008'),
            'smartone_merchant_id': params.get_param('smartone_cashbox_fiscal.smartone_merchant_id', ''),
            'smartone_enable_timer': str2bool(raw_timer_val),
            'smartone_check_status_timer': int(
                params.get_param('smartone_cashbox_fiscal.smartone_check_status_timer', 3)
            ),
        }
        _logger.info("=== [SUCCESS] SmartOne Configuration Loaded: %s ===", config_data)
        return config_data


# =====================================================
#   POS CONFIGURATION INHERITANCE
# =====================================================
class PosConfig(models.Model):
    _inherit = 'pos.config'

    def _get_pos_ui_res_config_settings(self, params):
        """POS UI yüklənərkən mərkəzi konfiqurasiya metodundan istifadə edir"""
        try:
            settings = self.env['res.config.settings'].get_smartone_config()
            _logger.info("=== [POS] UI Settings successfully synchronized ===")
            return settings
        except Exception as e:
            _logger.error("=== [POS] UI Settings load error: %s ===", str(e))
            return {}