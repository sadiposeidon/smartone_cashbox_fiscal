# -*- coding: utf-8 -*-
{
    'name': 'SmartOne Cashbox Fiscal',
    'version': '18.0.1.0.0',
    'category': 'Sales/Payment',
    'summary': 'Fiscal integration for SmartOne Cashbox',
    'author': 'Your Name',
    'website': 'https://www.google.com',
    'license': 'LGPL-3',
    'depends': ['base', 'web', 'sale', 'point_of_sale'],
    'data': [
        'views/res_config_settings_views.xml',
        'views/pos_order_views.xml',
    ],
    'assets': {
        'web.assets_backend': [
            'smartone_cashbox_fiscal/static/src/js/smartone_service.js',
            'smartone_cashbox_fiscal/static/src/js/smartone_settings.js',
        ],
        'point_of_sale._assets_pos': [
            'smartone_cashbox_fiscal/static/src/js/smartone_service.js',
            'smartone_cashbox_fiscal/static/src/js/smartone_pos.js',
            'smartone_cashbox_fiscal/static/src/js/PaymentScreen.js',
        ],
    },
    'installable': True,
    'application': True,
    'license': 'LGPL-3',
}