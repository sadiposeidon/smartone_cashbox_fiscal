/** @odoo-module **/

import { patch } from "@web/core/utils/patch";
import { PaymentScreen } from "@point_of_sale/app/screens/payment_screen/payment_screen";
import { PosOrder } from "@point_of_sale/app/models/pos_order";
import { useService } from "@web/core/utils/hooks";

// 1. Sifariş Modelini Patch edirik
patch(PosOrder.prototype, {
    setup(obj) {
        super.setup(...arguments);
        this.smartone_fiscal_id = this.smartone_fiscal_id || false;
        this.smartone_fiscal_num = this.smartone_fiscal_num || false;
        this.smartone_sent = this.smartone_sent || false;
    },
    export_as_JSON() {
        const json = super.export_as_JSON(...arguments);
        json.smartone_fiscal_id = this.smartone_fiscal_id;
        json.smartone_fiscal_num = this.smartone_fiscal_num;
        return json;
    },
    export_for_printing() {
        const result = super.export_for_printing(...arguments);
        result.smartone_fiscal_id = this.smartone_fiscal_id;
        result.smartone_fiscal_num = this.smartone_fiscal_num;
        return result;
    }
});

// 2. Ödəniş Ekranını Patch edirik
patch(PaymentScreen.prototype, {
    setup() {
        super.setup(...arguments);
        this.smartone = useService("smartone_service");
        this.notification = useService("notification");
        this.pos = useService("pos");
        this.orm = useService("orm");
        this._smartoneConfig = null;
        
        console.log("%c🚀 [SMARTONE] Peşəkar Debugger Aktivləşdirildi!", "color: white; background: #673ab7; padding: 4px; border-radius: 4px; font-weight: bold;");
    },

    /**
     * MƏRKƏZİ DEBUG LOG SİSTEMİ
     * Bütün əməliyyatları vizual olaraq qruplaşdırır.
     */
    _smartLog(type, action, data, isError = false) {
        const styles = {
            request: "background: #2196F3; color: white; font-weight: bold; padding: 2px 5px; border-left: 5px solid #0d47a1;",
            response: "background: #4CAF50; color: white; font-weight: bold; padding: 2px 5px; border-left: 5px solid #1b5e20;",
            error: "background: #F44336; color: white; font-weight: bold; padding: 2px 5px; border-left: 5px solid #b71c1c;",
            info: "background: #FF9800; color: white; font-weight: bold; padding: 2px 5px; border-left: 5px solid #e65100;"
        };
        const style = isError ? styles.error : styles[type] || styles.info;
        
        console.groupCollapsed(`%c SMARTONE | ${action.toUpperCase()} | ${new Date().toLocaleTimeString()} `, style);
        if (data) {
            if (typeof data === 'object') {
                console.table(data); // Obyektləri cədvəl formasında göstərir
            } else {
                console.log("Məlumat:", data);
            }
        }
        console.groupEnd();
    },

    async validateOrder(isForceValidate) {
        this._smartLog('info', 'Validayasiya Prosesi', "Başladı...");
        const order = this.pos.get_order();
        
        if (!order) {
            this._smartLog('error', 'Validayasiya', "Sifariş tapılmadı!", true);
            return super.validateOrder(...arguments);
        }

        if (order.smartone_sent || order.smartone_fiscal_id) {
            this._smartLog('info', 'Validayasiya', "Sifariş artıq göndərilib, keçilir.");
            return super.validateOrder(...arguments);
        }

        if (order.get_total_with_tax() <= 0) {
             return super.validateOrder(...arguments);
        }

        try {
            const success = await this.sendToSmartOne(order);
            if (success) {
                order.smartone_sent = true;
                this._smartLog('info', 'Validayasiya', "Kassa əməliyyatı uğurlu, Odoo-da təsdiqlənir.");
            }
        } catch (e) {
            this._smartLog('error', 'Validate Xətası', e, true);
        }

        return super.validateOrder(...arguments);
    },

    async sendToSmartOne(order) {
        try {
            if (!this._smartoneConfig) {
                this._smartoneConfig = await this.orm.call("res.config.settings", "get_smartone_config", [[]]);
            }
            const config = this._smartoneConfig;
            
            const items = [];
            for (const line of order.lines) {
                const product = line.product_id;
                if (!product) continue;

                let taxPrc = 1800; 
                if (line.tax_ids.length > 0) {
                    const tax = this.pos.models["account.tax"].get(line.tax_ids[0]);
                    if (tax) taxPrc = tax.amount * 100;
                }

                items.push({
                    "itemId": product.id.toString(),
                    "itemName": product.display_name || product.name,
                    "itemQty": Math.round(line.qty * 1000),
                    "itemAmount": Math.round(line.price_subtotal_incl * 100),
                    "itemTaxes": [{ "taxName": "ƏDV", "taxCode": "4", "taxPrc": taxPrc, "calcType": 1 }]
                });
            }

            let cash = 0, cashless = 0;
            for (const p of order.payment_ids) {
                if (p.payment_method_id.type === 'cash') cash += p.amount;
                else cashless += p.amount;
            }

            const payload = {
                "docNumber": order.name,
                "amount": Math.round(order.get_total_with_tax() * 100),
                "currency": "AZN",
                "employeeName": this.pos.get_cashier().name,
                "items": items,
                "payments": {
                    "cashAmount": Math.round(cash * 100),
                    "cashlessAmount": Math.round(cashless * 100)
                }
            };

            const url = this.smartone.getFullUrl(config.smartone_url, config.smartone_port, "sale");
            this._smartLog('request', 'Satış Sorğusu (SALE)', { url, payload });

            const res = await this.smartone.sendRequest(url, payload, config.smartone_merchant_id);
            this._smartLog('response', 'Satış Cavabı', res);

            const f_id = res?.fiscalID || res?.fiscalId;
            if (f_id) {
                order.smartone_fiscal_id = f_id;
                order.smartone_fiscal_num = res?.documentID || res?.documentId;
                this.notification.add(`Fiskal ID: ${f_id}`, { type: "success" });
                return true;
            }
            return false;
        } catch (error) {
            this._smartLog('error', 'Kritik API Xətası (SALE)', error, true);
            return false;
        }
    },

    // --- SMARTONE ƏLAVƏ DÜYMƏLƏR ---

    async action_smartone_refund() {
        this._smartLog('info', 'Refund', "Geri qaytarma prosesi başladı...");
        const order = this.pos.get_order();
        try {
            if (!this._smartoneConfig) this._smartoneConfig = await this.orm.call("res.config.settings", "get_smartone_config", [[]]);
            const config = this._smartoneConfig;

            const payload = {
                "docNumber": order.name,
                "amount": Math.round(order.get_total_with_tax() * 100),
                "fiscalId": order.smartone_fiscal_id
            };
            const url = this.smartone.getFullUrl(config.smartone_url, config.smartone_port, "refund");

            this._smartLog('request', 'Refund Sorğusu', { url, payload });
            const res = await this.smartone.sendRequest(url, payload, config.smartone_merchant_id);
            this._smartLog('response', 'Refund Cavabı', res);

            if (res?.status === 'success' || res?.fiscalID) {
                this.notification.add("Geri qaytarma uğurlu!", { type: "success" });
            }
        } catch (e) {
            this._smartLog('error', 'Refund Xətası', e, true);
        }
    },

    async action_smartone_rollback() {
        this._smartLog('info', 'Rollback', "Son əməliyyatın ləğvi...");
        try {
            if (!this._smartoneConfig) this._smartoneConfig = await this.orm.call("res.config.settings", "get_smartone_config", [[]]);
            const config = this._smartoneConfig;

            const url = this.smartone.getFullUrl(config.smartone_url, config.smartone_port, "rollback");
            this._smartLog('request', 'Rollback Sorğusu', { url });

            const res = await this.smartone.sendRequest(url, {}, config.smartone_merchant_id);
            this._smartLog('response', 'Rollback Cavabı', res);
        } catch (e) {
            this._smartLog('error', 'Rollback Xətası', e, true);
        }
    },

    async action_smartone_check_copy() {
        this._smartLog('info', 'Check Copy', "Çek surəti çıxarılır...");
        try {
            if (!this._smartoneConfig) this._smartoneConfig = await this.orm.call("res.config.settings", "get_smartone_config", [[]]);
            const config = this._smartoneConfig;

            const url = this.smartone.getFullUrl(config.smartone_url, config.smartone_port, "copy");
            this._smartLog('request', 'Copy Sorğusu', { url });

            const res = await this.smartone.sendRequest(url, {}, config.smartone_merchant_id);
            this._smartLog('response', 'Copy Cavabı', res);
        } catch (e) {
            this._smartLog('error', 'Copy Xətası', e, true);
        }
    }
});