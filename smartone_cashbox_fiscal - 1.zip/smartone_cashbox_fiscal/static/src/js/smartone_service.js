/** @odoo-module **/

import { registry } from "@web/core/registry";

export const smartoneService = {
    dependencies: ["notification"],
    start(env, { notification }) {
        
        async function generateSignature(base64Data, merchantId) {
            console.groupCollapsed("%c [SmartOne] 1. İmza Hazırlanır ", "color: #3498db; font-weight: bold;");
            const message = base64Data + merchantId;
            const msgUint8 = new TextEncoder().encode(message);
            const hashBuffer = await crypto.subtle.digest('SHA-1', msgUint8);
            const hashArray = Array.from(new Uint8Array(hashBuffer));
            const sha1Hex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
            const finalSign = btoa(sha1Hex);
            
            console.log("Qatışdırılmış Data:", message);
            console.log("SHA1 Hex:", sha1Hex);
            console.log("Final Signature (Base64):", finalSign);
            console.groupEnd();
            return finalSign;
        }

        function getFullUrl(url, port, endpoint) {
            if (!url) return false;
            let cleanUrl = url.trim();
            if (!cleanUrl.startsWith('http')) cleanUrl = 'http://' + cleanUrl;
            cleanUrl = cleanUrl.replace(/\/$/, "");
            if (port && !cleanUrl.includes(':' + port)) cleanUrl += ":" + port;
            return `${cleanUrl}/${endpoint}`;
        }

        async function sendRequest(url, dataObj, merchantId) {
            const requestTime = new Date().toLocaleTimeString();
            console.group(`%c [SmartOne API Request] - ${requestTime} `, "background: #2c3e50; color: #fff; padding: 5px; border-radius: 3px;");
            
            try {
                if (!url || !merchantId) throw new Error("URL və ya Merchant ID çatışmır!");

                const jsonData = JSON.stringify(dataObj);
                const base64Data = btoa(unescape(encodeURIComponent(jsonData)));
                const sign = await generateSignature(base64Data, merchantId);

                const params = new URLSearchParams();
                params.append('data', base64Data);
                params.append('sign', sign);

                console.log("%c Endpoint: ", "font-weight: bold;", url);
                console.log("%c Payload Object: ", "color: #e67e22;", dataObj);

                const response = await fetch(url, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: params.toString()
                });

                const resultText = await response.text();
                let resultJson;
                try {
                    resultJson = JSON.parse(resultText);
                } catch (e) {
                    resultJson = { status: "raw", response: resultText };
                }

                if (response.ok) {
                    console.log("%c [SUCCESS] Kassa Cavabı: ", "color: #27ae60; font-weight: bold;", resultJson);
                } else {
                    console.error(`%c [HTTP ERROR] Status: ${response.status} `, "background: #c0392b; color: white;", resultJson);
                }
                return resultJson;

            } catch (error) {
                console.error("%c [CRITICAL ERROR] ", "background: red; color: white;", error.message);
                throw error;
            } finally {
                console.groupEnd();
            }
        }

        return { getFullUrl, sendRequest };
    },
};

registry.category("services").add("smartone_service", smartoneService);