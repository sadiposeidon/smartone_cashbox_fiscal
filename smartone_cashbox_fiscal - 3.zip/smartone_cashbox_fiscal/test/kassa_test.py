import os
from flask import Flask, request, jsonify
from flask_cors import CORS
import json
import base64
import hashlib
from urllib.parse import unquote
from datetime import datetime

app = Flask(__name__)
CORS(app)

# Tənzimləmələr
MERCHANT_ID = "9662a13f5b4f46dbb1751bbbf86ed402" 
PORT = 8008

# Rəng Kodları
G = "\033[1;32m"  # Yaşıl (Sale)
B = "\033[1;34m"  # Mavi (Copy / Data)
W = "\033[1;37m"  # Ağ (Çərçivə)
R = "\033[1;31m"  # Qırmızı (Rollback)
Y = "\033[1;33m"  # Sarı (Refund)
RESET = "\033[0m"

def setup_terminal():
    if os.name == "nt": 
        os.system("cls")
        os.system("color 0A")
    else:
        os.system("clear")

def print_tree(data, indent=0):
    prefix = "    " * indent
    if isinstance(data, dict):
        items = list(data.items())
        for i, (key, value) in enumerate(items):
            is_last = (i == len(items) - 1)
            connector = "└── " if is_last else "├── "
            if isinstance(value, (dict, list)):
                print(f"{prefix}{connector}{G}{key}{RESET}")
                print_tree(value, indent + 1)
            else:
                print(f"{prefix}{connector}{G}{key}: {B}{value}{RESET}")
    elif isinstance(data, list):
        for i, item in enumerate(data):
            is_last = (i == len(data) - 1)
            connector = "└── " if is_last else "├── "
            print(f"{prefix}{connector}{W}[Element {i+1}]{RESET}")
            print_tree(item, indent + 1)

def verify_and_decode(request_form):
    """ API sənədinə uyğun imza yoxlanışı və deşifrə (SHA1 + Base64) """
    data_raw = request_form.get('data', '')
    sign_from_odoo = request_form.get('sign', '')
    
    # İmza: data + merchantID -> sha1 (hex, lowercase) -> base64encode
    raw_string = (data_raw + MERCHANT_ID).encode('utf-8')
    sha1_hash = hashlib.sha1(raw_string).hexdigest().lower()
    expected_sign = base64.b64encode(sha1_hash.encode('utf-8')).decode('utf-8')
    
    is_valid = (sign_from_odoo == expected_sign)
    
    try:
        decoded_bytes = base64.b64decode(data_raw)
        decoded_str = unquote(decoded_bytes.decode('utf-8'))
        json_data = json.loads(decoded_str)
    except Exception as e:
        json_data = {"error": f"Deşifrə xətası: {str(e)}"}
    
    return is_valid, json_data

def get_request_data():
    """ Həm imzalı Form-Data, həm də birbaşa JSON sorğularını qəbul edir """
    if 'data' in request.form:
        return verify_and_decode(request.form)
    else:
        # Birbaşa JSON (Odoo bəzən bunu istifadə edir)
        data = request.get_json() if request.is_json else request.form.to_dict()
        return True, data

def print_header(title, color=W):
    print(f"\n{color}╔" + "═"*60 + "╗")
    print(f"║ {title.center(58)} ║")
    print("╠" + "═"*60 + "╣" + f"{RESET}")

def print_footer(color=W):
    print(f"{color}╚" + "═"*60 + "╝" + f"{RESET}")

# 1. /get_info – Token-dən məlumatların alınması
@app.route('/get_info', methods=['POST'])
def get_info():
    is_valid, json_data = get_request_data()
    print_header("CİHAZ MƏLUMATLARI (GET_INFO)", W)
    print_tree(json_data)
    print_footer(W)
    return jsonify({
        "status": "success",
        "deviceInfo": {
            "version": "v3.9",
            "serialNumber": "AZ-SMART-888888",
            "model": "SmartOne Virtual Cashbox",
            "merchantID": MERCHANT_ID
        }
    })

# 2. /check_status – Hesabatın vəziyyətinin yoxlanması
@app.route('/check_status', methods=['POST'])
def check_status():
    is_valid, json_data = get_request_data()
    print_header("STATUS YOXLAMA (CHECK_STATUS)", W)
    print_tree(json_data)
    print(f"║ {W}Status: {G}OK (ONLINE){' '*(41)} {W}║")
    print_footer(W)
    return jsonify({
        "status": "success",
        "message": "Cihaz hazırdır",
        "docStatus": 1, 
        "dateTime": datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    })

# 3. /sale – Satış hesabının fiskallaşdırılması
@app.route('/sale', methods=['POST'])
def sale():
    is_valid, json_data = get_request_data()
    print_header("SATIŞ ƏMƏLİYYATI (SALE)", G)
    print(f"║ {W}Zaman:  {B}{datetime.now().strftime('%H:%M:%S')}{' '*(41)} {W}║")
    print(f"║ {W}İmza:   {G if is_valid else R}{'✅ DOGRU' if is_valid else '❌ YALNIS'}{' '*(42)} {W}║")
    print(f"{W}╠" + "═"*60 + "╣")
    print_tree(json_data)
    print_footer(G)
    
    return jsonify({
        "status": "success", 
        "code": 0,
        "documentID": "DOC-" + datetime.now().strftime("%H%M%S"),
        "fiscalID": "AZ" + datetime.now().strftime("%Y%m%d%H%M%S"), 
        "fiscalNum": "SN-" + datetime.now().strftime("%f")[:4],
        "checkNum": "552",
        "qrCodeUrl": "https://monitoring.e-kassa.az/"
    })

# 4. /refund – Qaytarma hesabatının göndərilməsi
@app.route('/refund', methods=['POST'])
def refund():
    is_valid, json_data = get_request_data()
    print_header("GERİ QAYTARMA (REFUND)", Y)
    print(f"║ {W}Zaman:  {B}{datetime.now().strftime('%H:%M:%S')}{' '*(41)} {W}║")
    print(f"{W}╠" + "═"*60 + "╣")
    print_tree(json_data)
    print_footer(Y)
    return jsonify({
        "status": "success", 
        "documentID": "REF-" + datetime.now().strftime("%H%M%S"),
        "fiscalID": "REF-AZ-" + datetime.now().strftime("%Y%m%d")
    })

# 5. /rollback – Hesabatın ləğv edilməsi
@app.route('/rollback', methods=['POST'])
def rollback():
    is_valid, json_data = get_request_data()
    print_header("LƏĞV ETMA (ROLLBACK)", R)
    print(f"║ {W}Zaman:  {B}{datetime.now().strftime('%H:%M:%S')}{' '*(41)} {W}║")
    print(f"{W}╠" + "═"*60 + "╣")
    print_tree(json_data)
    print_footer(R)
    return jsonify({
        "status": "success", 
        "message": "Əməliyyat uğurla ləğv edildi"
    })

# 6. /check_copy – Çek nüsxəsinin çap edilməsi
@app.route('/check_copy', methods=['POST'])
def check_copy():
    is_valid, json_data = get_request_data()
    print_header("ÇEK NÜSXƏSİ (COPY)", B)
    print(f"║ {W}Zaman:  {B}{datetime.now().strftime('%H:%M:%S')}{' '*(41)} {W}║")
    print(f"{W}╠" + "═"*60 + "╣")
    print_tree(json_data)
    print_footer(B)
    return jsonify({
        "status": "success", 
        "message": "Nüsxə çapa göndərildi"
    })

if __name__ == '__main__':
    setup_terminal()
    print(f"{W}╔" + "═"*60 + "╗")
    print(f"║{G}       AZSMART VIRTUAL KASSA SERVER - VERSION 3.9 (Odoo 18){W}     ║")
    print(f"║{G}       PORT: {B}{PORT}{G} | MERCHANT: {B}{MERCHANT_ID}{G} | STATUS: {B}ONLINE{G}       {W}║")
    print(f"╚" + "═"*60 + "╝{RESET}")
    app.run(host='0.0.0.0', port=PORT, debug=False)