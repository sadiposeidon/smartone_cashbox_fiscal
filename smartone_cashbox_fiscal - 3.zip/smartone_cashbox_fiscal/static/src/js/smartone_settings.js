/** @odoo-module **/

import { patch } from "@web/core/utils/patch";
import { SettingsFormController } from "@web/webclient/settings_form_view/settings_form_controller";
import { FormController } from "@web/views/form/form_controller"; // Backend form düymələri üçün
import { useService } from "@web/core/utils/hooks";
import { useEffect } from "@odoo/owl";

// --- 1. AYARLAR EKRANI ÜÇÜN PATCH (SettingsFormController) ---
patch(SettingsFormController.prototype, {
    setup() {
        super.setup(...arguments);
        this.notification = useService("notification");
        this.orm = useService("orm");
        this.smartone = useService("smartone_service");

        useEffect(() => {
            const el = document.querySelector(".o_settings_container");
            if (!el) return;
            const handleClicks = async (ev) => {
                const btn = ev.target.closest(".js_smartone_check_device, .js_smartone_check_status");
                if (btn) {
                    const isCheckDevice = btn.classList.contains("js_smartone_check_device");
                    await this.executeAction(isCheckDevice ? "get_info" : "check_status");
                }
            };
            el.addEventListener("click", handleClicks);
            return () => el.removeEventListener("click", handleClicks);
        }, () => []);
    },

    async executeAction(endpoint) {
        const d = this.model.root.data;
        if (!d.smartone_url || !d.smartone_merchant_id) {
            return this.notification.add("URL və Merchant ID doldurulmalıdır!", { type: "danger" });
        }

        const url = this.smartone.getFullUrl(d.smartone_url, d.smartone_port, endpoint);
        const payload = { 
            "employeeName": "Odoo Admin", 
            "documentExtID": d.smartone_document_ext_id || "" 
        };

        try {
            const res = await this.smartone.sendRequest(url, payload, d.smartone_merchant_id);
            
            // Backend-də loqlama funksiyasını çağırırıq
            if (this.orm && typeof this.orm.call === 'function') {
                await this.orm.call("res.config.settings", "log_smartone_debug", [res]);
            }
            
            this.notification.add("Sorğu tamamlandı (Console-a baxın)", { type: "info" });
        } catch (e) {
            this.notification.add("Bağlantı xətası!", { type: "danger" });
        }
    }
});

// --- 2. SİFARİŞ FORMU ÜÇÜN PATCH (FormController) ---
// Bu hissə backend-dəki "pos.order" formundakı düymələri fetch-ə yönləndirir.
patch(FormController.prototype, {
    setup() {
        super.setup(...arguments);
        this.smartone = useService("smartone_service");
        this.orm = useService("orm");
        this.notification = useService("notification");
    },

    /**
     * Backend düyməsinə basıldıqda Python metoduna getmədən öncə işə düşür.
     */
    async beforeExecuteActionButton(clickAction) {
        const actionName = clickAction.name;
        const targetButtons = ["action_smartone_refund", "action_smartone_rollback", "action_smartone_check_copy"];

        if (targetButtons.includes(actionName) && this.model.root.resModel === "pos.order") {
            const data = this.model.root.data;
            
            // Service loqlamasını istifadə edirik (əgər service-də varsa)
            if (this.smartone._smartLog) {
                this.smartone._smartLog('info', 'BACKEND BUTTON CLICK', `Düymə: ${actionName}`);
            }

            try {
                // Konfiqurasiyanı backend-dən alırıq
                const config = await this.orm.call("res.config.settings", "get_smartone_config", [[]]);
                
                let endpoint = "";
                let payload = { "employeeName": "Odoo Admin" };

                if (actionName === "action_smartone_refund") {
                    endpoint = "refund";
                    payload.documentID = data.smartone_fiscal_num;
                    if (!payload.documentID) {
                        this.notification.add("Bu sifarişin fiskal nömrəsi yoxdur!", { type: "danger" });
                        return false; 
                    }
                } else if (actionName === "action_smartone_rollback") {
                    endpoint = "rollback";
                } else if (actionName === "action_smartone_check_copy") {
                    endpoint = "check_copy";
                }

                const url = this.smartone.getFullUrl(config.smartone_url, config.smartone_port, endpoint);
                const res = await this.smartone.sendRequest(url, payload, config.smartone_merchant_id);
                
                if (res) {
                    this.notification.add("Kassa əməliyyatı uğurla icra edildi.", { type: "success" });
                }
            } catch (e) {
                this.notification.add("Kassa ilə bağlantı xətası!", { type: "danger" });
            }

            // Return false edərək Python metodunun (backend serverin) çağırılmasını ləğv edirik.
            return false; 
        }
        return super.beforeExecuteActionButton(...arguments);
    }
});