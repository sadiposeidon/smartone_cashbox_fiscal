/** @odoo-module **/

import { registry } from "@web/core/registry";

export const smartoneService = {
    dependencies: ["notification"],
    start(env, { notification }) {
        
        /**
         * PEŞƏKAR DEBUG LOG SİSTEMİ
         * Brauzer konsolunda sorğuları və cavabları rəngli və qruplaşdırılmış şəkildə göstərir.
         */
        const _smartLog = (type, action, data, isError = false) => {
            const styles = {
                request: "background: #2196F3; color: white; font-weight: bold; padding: 4px; border-radius: 4px;",
                response: "background: #4CAF50; color: white; font-weight: bold; padding: 4px; border-radius: 4px;",
                error: "background: #F44336; color: white; font-weight: bold; padding: 4px; border-radius: 4px;",
                info: "background: #FF9800; color: white; font-weight: bold; padding: 4px; border-radius: 4px;"
            };
            const style = isError ? styles.error : styles[type] || styles.info;
            const icon = isError ? "❌" : (type === 'request' ? "📡" : "✅");
            
            console.groupCollapsed(`%c ${icon} SMARTONE | ${action.toUpperCase()} | ${new Date().toLocaleTimeString()} `, style);
            if (data) {
                console.log("%cMəlumat Detalı:", "color: #2c3e50; font-weight: bold;");
                if (typeof data === 'object') {
                    console.table(data);
                    console.log("Tam Obyekt:", data);
                } else {
                    console.log("Mesaj:", data);
                }
            }
            console.groupEnd();
        };

        /**
         * Kassaya göndərilən datanı imzalayır (SHA-1)
         */
        async function generateSignature(base64Data, merchantId) {
            _smartLog('info', 'Signature Generation Started', { base64Data, merchantId });
            const message = base64Data + merchantId;
            const msgUint8 = new TextEncoder().encode(message);
            const hashBuffer = await crypto.subtle.digest('SHA-1', msgUint8);
            const hashArray = Array.from(new Uint8Array(hashBuffer));
            const sha1Hex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
            const finalSign = btoa(sha1Hex);
            
            console.log("%cSHA1 Hex Result:", "color: #3498db; font-style: italic;", sha1Hex);
            return finalSign;
        }

        /**
         * URL-i təmizləyir və endpoint-i əlavə edir
         */
        function getFullUrl(url, port, endpoint) {
            if (!url) return false;
            let cleanUrl = url.trim();
            if (!cleanUrl.startsWith('http')) cleanUrl = 'http://' + cleanUrl;
            cleanUrl = cleanUrl.replace(/\/$/, ""); // Sondakı slash-ı silir
            if (port && !cleanUrl.includes(':' + port)) cleanUrl += ":" + port;
            return `${cleanUrl}/${endpoint}`;
        }

        /**
         * Kassaya birbaşa Fetch API ilə POST sorğusu göndərir
         */
        async function sendRequest(url, dataObj, merchantId) {
            _smartLog('request', `API SORĞUSU: ${url}`, dataObj);
            
            try {
                const jsonData = JSON.stringify(dataObj);
                // UTF-8 dəstəyi ilə Base64-ə çevirmə
                const base64Data = btoa(unescape(encodeURIComponent(jsonData)));
                const sign = await generateSignature(base64Data, merchantId);
                
                const params = new URLSearchParams();
                params.append('data', base64Data);
                params.append('sign', sign);

                const response = await fetch(url, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: params.toString()
                });

                if (!response.ok) {
                    throw new Error(`HTTP Xətası! Status: ${response.status}`);
                }

                const resultText = await response.text();
                let resultJson = JSON.parse(resultText || "{}");
                
                _smartLog('response', "API CAVABI ALINDI", resultJson);
                return resultJson;
                
            } catch (error) {
                _smartLog('error', "API KRİTİK XƏTA", error.message || error, true);
                notification.add("Kassa aparatı ilə bağlantı qurularkən xəta baş verdi!", { 
                    type: "danger",
                    sticky: true 
                });
                throw error;
            }
        }

        return { 
            getFullUrl, 
            sendRequest, 
            _smartLog // Digər fayllardan loqlama üçün əlçatan edirik
        };
    },
};

registry.category("services").add("smartone_service", smartoneService);