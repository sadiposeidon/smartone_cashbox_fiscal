/** @odoo-module **/

import { patch } from "@web/core/utils/patch";
import { PaymentScreen } from "@point_of_sale/app/screens/payment_screen/payment_screen";
import { TicketScreen } from "@point_of_sale/app/screens/ticket_screen/ticket_screen";
import { PosOrder } from "@point_of_sale/app/models/pos_order";
import { FormController } from "@web/views/form/form_controller"; 
import { useService } from "@web/core/utils/hooks";

// --- 1. Sifariş Modelini Patch edirik (Data Persistency) ---
patch(PosOrder.prototype, {
    setup(obj) {
        super.setup(...arguments);
        // Fiskal məlumatların itməməsi üçün model səviyyəsində inisializasiya
        this.smartone_fiscal_id = this.smartone_fiscal_id || false;
        this.smartone_fiscal_num = this.smartone_fiscal_num || false;
        this.smartone_sent = this.smartone_sent || false;
    },
    export_as_JSON() {
        const json = super.export_as_JSON(...arguments);
        // Serverə (Backend) göndəriləcək dataya əlavə edirik
        json.smartone_fiscal_id = this.smartone_fiscal_id;
        json.smartone_fiscal_num = this.smartone_fiscal_num;
        return json;
    },
    export_for_printing() {
        const result = super.export_for_printing(...arguments);
        // Çekdə (Receipt) istifadə olunacaq dataya əlavə edirik
        result.smartone_fiscal_id = this.smartone_fiscal_id;
        result.smartone_fiscal_num = this.smartone_fiscal_num;
        return result;
    }
});

// --- 2. Ödəniş Ekranını Patch edirik (UI Logic & API) ---
patch(PaymentScreen.prototype, {
    setup() {
        super.setup(...arguments);
        this.smartone = useService("smartone_service");
        this.notification = useService("notification");
        this.orm = useService("orm");
        this._smartoneConfig = null;

        console.log("%c🚀 [SMARTONE] Peşəkar Debugger Aktivləşdirildi!", "color: white; background: #673ab7; padding: 4px; border-radius: 4px; font-weight: bold;");
    },

    /**
     * PEŞƏKAR DEBUG LOG SİSTEMİ
     */
    _smartLog(type, action, data, isError = false) {
        const styles = {
            request: "background: #2196F3; color: white; font-weight: bold; padding: 2px 5px; border-left: 8px solid #0d47a1;",
            response: "background: #4CAF50; color: white; font-weight: bold; padding: 2px 5px; border-left: 8px solid #1b5e20;",
            error: "background: #F44336; color: white; font-weight: bold; padding: 2px 5px; border-left: 8px solid #b71c1c;",
            info: "background: #FF9800; color: white; font-weight: bold; padding: 2px 5px; border-left: 8px solid #e65100;"
        };
        const style = isError ? styles.error : styles[type] || styles.info;
        const icon = isError ? "❌" : (type === 'request' ? "📡" : "✅");
        
        console.groupCollapsed(`%c ${icon} SMARTONE | ${action.toUpperCase()} | ${new Date().toLocaleTimeString()} `, style);
        if (data) {
            if (typeof data === 'object') {
                console.table(data);
                console.log("Tam Obyekt:", data);
            } else {
                console.log("Mesaj:", data);
            }
        }
        console.groupEnd();
    },

    /**
     * Sifarişi təsdiqləməzdən əvvəl (Validate) kassaya sorğu göndərir.
     */
    async validateOrder(isForceValidate) {
        this._smartLog('info', 'Validayasiya Prosesi', "Sifariş təsdiqlənməyə hazırlanır...");
        const order = this.pos.get_order();
        
        if (!order) {
            this._smartLog('error', 'Validayasiya', "Sifariş obyekti tapılmadı!", true);
            return super.validateOrder(...arguments);
        }

        if (order.smartone_sent || order.smartone_fiscal_id) {
            this._smartLog('info', 'Validayasiya', "Sifariş artıq kassaya göndərilib. Birbaşa təsdiqlənir.");
            return super.validateOrder(...arguments);
        }

        if (order.get_total_with_tax() <= 0) {
             this._smartLog('info', 'Validayasiya', "Məbləğ 0 və ya mənfidir, kassa sorğusu atılmır.");
             return super.validateOrder(...arguments);
        }

        try {
            const success = await this.sendToSmartOne(order);
            if (success) {
                order.smartone_sent = true;
                this._smartLog('info', 'Validayasiya', "Kassa əməliyyatı uğurlu, Odoo yaddaşına ötürülür.");
            } else {
                this._smartLog('info', 'Validayasiya', "Kassa sorğusu uğursuz oldu, lakin validasiya davam etdirilir.");
            }
        } catch (e) {
            this._smartLog('error', 'Validate Xətası', e.message || e, true);
        }

        return super.validateOrder(...arguments);
    },

    /**
     * Əsas Satış (SALE) sorğusu.
     */
    async sendToSmartOne(order) {
        try {
            if (!this._smartoneConfig) {
                this._smartoneConfig = await this.orm.call("res.config.settings", "get_smartone_config", [[]]);
            }
            const config = this._smartoneConfig;
            
            const items = order.lines.map(line => {
                let taxPrc = 1800;
                if (line.tax_ids.length > 0) {
                    const tax = this.pos.models["account.tax"].get(line.tax_ids[0]);
                    if (tax) taxPrc = tax.amount * 100;
                }
                return {
                    "itemId": line.product_id.id.toString(),
                    "itemName": line.product_id.display_name || line.product_id.name,
                    "itemQty": Math.round(line.qty * 1000),
                    "itemAmount": Math.round(line.price_subtotal_incl * 100),
                    "itemTaxes": [{ "taxName": "ƏDV", "taxCode": "4", "taxPrc": taxPrc, "calcType": 1 }]
                };
            });

            let cash = 0, cashless = 0;
            for (const p of order.payment_ids) {
                if (p.payment_method_id.type === 'cash') cash += p.amount;
                else cashless += p.amount;
            }

            const payload = {
                "docNumber": order.name,
                "amount": Math.round(order.get_total_with_tax() * 100),
                "currency": "AZN",
                "employeeName": this.pos.get_cashier().name,
                "items": items,
                "payments": {
                    "cashAmount": Math.round(cash * 100),
                    "cashlessAmount": Math.round(cashless * 100)
                }
            };

            const url = this.smartone.getFullUrl(config.smartone_url, config.smartone_port, "sale");
            this._smartLog('request', 'Satış Sorğusu (SALE)', { url, payload });

            const res = await this.smartone.sendRequest(url, payload, config.smartone_merchant_id);
            this._smartLog('response', 'Satış Cavabı', res);

            if (res?.fiscalID) {
                order.smartone_fiscal_id = res.fiscalID;
                order.smartone_fiscal_num = res.documentID;
                this.notification.add(`Uğurlu! Fiskal ID: ${res.fiscalID}`, { type: "success" });
                return true;
            }
            return false;
        } catch (error) {
            this._smartLog('error', 'Kritik API Xətası (SALE)', error, true);
            return false;
        }
    },

    // --- SMARTONE FRONTEND DÜYMƏLƏRİ ---

    async action_smartone_refund() {
        this._smartLog('info', 'Refund', "Qaytarma (Refund) prosesi başladıldı.");
        const order = this.pos.get_order();
        if (!order || !order.smartone_fiscal_num) {
            this.notification.add("Bu sifarişin Fiskal ID-si yoxdur!", { type: "danger" });
            return;
        }
        try {
            if (!this._smartoneConfig) this._smartoneConfig = await this.orm.call("res.config.settings", "get_smartone_config", [[]]);
            const config = this._smartoneConfig;
            const url = this.smartone.getFullUrl(config.smartone_url, config.smartone_port, "refund");
            const res = await this.smartone.sendRequest(url, { "documentID": order.smartone_fiscal_num, "employeeName": this.pos.get_cashier().name }, config.smartone_merchant_id);
            if (res) this.notification.add("Refund uğurla icra olundu.", { type: "success" });
        } catch (e) { this._smartLog('error', 'Refund Xətası', e, true); }
    },

    async action_smartone_rollback() {
        this._smartLog('info', 'Rollback', "Son əməliyyatın ləğvi başladılır...");
        try {
            if (!this._smartoneConfig) this._smartoneConfig = await this.orm.call("res.config.settings", "get_smartone_config", [[]]);
            const config = this._smartoneConfig;
            const url = this.smartone.getFullUrl(config.smartone_url, config.smartone_port, "rollback");
            const res = await this.smartone.sendRequest(url, {}, config.smartone_merchant_id);
            if (res) this.notification.add("Son əməliyyat uğurla ləğv edildi.", { type: "warning" });
        } catch (e) { this._smartLog('error', 'Rollback Xətası', e, true); }
    },

    async action_smartone_check_copy() {
        this._smartLog('info', 'Check Copy', "Çek nüsxəsinin çapı tələb olunur...");
        try {
            if (!this._smartoneConfig) this._smartoneConfig = await this.orm.call("res.config.settings", "get_smartone_config", [[]]);
            const config = this._smartoneConfig;
            const url = this.smartone.getFullUrl(config.smartone_url, config.smartone_port, "check_copy");
            const res = await this.smartone.sendRequest(url, {}, config.smartone_merchant_id);
            if (res) this.notification.add("Çek nüsxəsi çap edildi.", { type: "info" });
        } catch (e) { this._smartLog('error', 'Copy Xətası', e, true); }
    }
});

// --- 3. TicketScreen Patch (POS UI Sifariş siyahısındakı düymələr üçün) ---
patch(TicketScreen.prototype, {
    setup() {
        super.setup(...arguments);
        this.smartone = useService("smartone_service");
        this.orm = useService("orm");
        this.notification = useService("notification");
    },
    async _executeSmartoneAction(order, action) {
        try {
            const config = await this.orm.call("res.config.settings", "get_smartone_config", [[]]);
            const url = this.smartone.getFullUrl(config.smartone_url, config.smartone_port, action);
            const res = await this.smartone.sendRequest(url, { 
                "documentID": order.smartone_fiscal_num || "", 
                "employeeName": this.pos.get_cashier().name 
            }, config.smartone_merchant_id);
            if (res) this.notification.add(`${action} uğurla icra edildi.`, { type: "success" });
        } catch (e) { console.error(e); }
    },
    async onRefundOrder(order) {
        await this._executeSmartoneAction(order, 'refund');
        return super.onRefundOrder(...arguments);
    },
    async action_smartone_rollback(order) { await this._executeSmartoneAction(order, 'rollback'); },
    async action_smartone_check_copy(order) { await this._executeSmartoneAction(order, 'check_copy'); }
});

// --- 4. FormController Patch (BACKEND SORĞUSUNU BLOKLAMAQ ÜÇÜN) ---
patch(FormController.prototype, {
    setup() {
        super.setup(...arguments);
        this.smartone = useService("smartone_service");
        this.orm = useService("orm");
        this.notification = useService("notification");
    },
    async beforeExecuteActionButton(clickParams) {
        const smartoneActions = ['action_smartone_refund', 'action_smartone_rollback', 'action_smartone_check_copy'];
        
        if (smartoneActions.includes(clickParams.name)) {
            // BACKEND-Ə GEDƏN YOLU BURADA TAM BAĞLAYIRIQ
            console.log(`%c🚫 [BLOCK] Backend sorğusu ləğv edildi: ${clickParams.name}`, "color: yellow; background: red; font-weight: bold;");
            
            const record = this.model.root;
            const actionType = clickParams.name.replace('action_smartone_', '');

            try {
                const config = await this.orm.call("res.config.settings", "get_smartone_config", [[]]);
                const url = this.smartone.getFullUrl(config.smartone_url, config.smartone_port, actionType);
                
                await this.smartone.sendRequest(url, {
                    "documentID": record.data.smartone_fiscal_num || "",
                    "employeeName": record.data.user_id ? record.data.user_id[1] : "Administrator"
                }, config.smartone_merchant_id);

                this.notification.add("Kassa məliyyatı uğurla tamamlandı.", { type: "success" });
            } catch (e) {
                this.notification.add("Kassa sorğusu uğursuz oldu.", { type: "danger" });
            }

            // 'false' qaytarmaqla Odoo-nun Python tərəfindəki metodu çağırmasını əngəlləyirik.
            return false; 
        }
        return super.beforeExecuteActionButton(...arguments);
    }
});